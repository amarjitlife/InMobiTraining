
//_________________________________________________________
//_________________________________________________________

/*
// 	Static Use Cases In Java/C++
//		To Bind State/Behaviour with Class/Type
//		Type Member

//	Alternative Design Choices

// 1. Singleton
//		Class Having Only One Instance

// 2. Factory Method
*/



//_________________________________________________________
//
// 1. Use Case: Singleton
//		Class Having Only One Instance
//
//_________________________________________________________

package logging:
	
// In Scala
// object Class Are Singleton Classes

	object Logger:
		def info( message: String ): Unit = println(s"INFO: $message")


def playWithSingleton =

	import logging.Logger

	class Project( name: String, daysToComplete: Int )

	class Test:
		val project1 = Project("Nation Building", 99)
		val project2 = Project("Training and Learning", 30 )

		Logger.info("Created Projects")

	Test()

// The info method is visible because of the import statement, 
//		import logging.Logger.info.

//	Imports require a “stable path” to the imported symbol, and 
//		an object is a stable path.

// Note: 
//	If an object is not top-level but is nested 
//		in another class or object, then the object is 
//		“Path-Dependent” like any other member. 

//	This means that given two kinds of beverages, 
//		class Milk and class OrangeJuice, 

// 		A class member object NutritionInfo 

//		“depends” on the enclosing instance, 
//			either milk or orange juice. 

//		milk.NutritionInfo is entirely distinct from oj.NutritionInfo.


//_________________________________________________________
//
// Companion Objects
// 		An object with the same name as a class is 
//		called a companion object. 
//
//_________________________________________________________


import scala.math.{Pi, pow}

// Companion Object For Type Circle

//		A companion class or object can access 
//			the private members of its companion. 
//		Use a companion object for methods and values 
//			which are not specific to 
//			instances of the companion class.

// Note: If a class or object has a companion, both must be 
// 		defined in the same file. 

object Circle:
	private def calculateArea( radius : Double ) = Pi * pow( radius, 2.0 )

case class Circle( radius: Double ):
	import Circle.*
	def area: Double = calculateArea( radius )


def playWithCompanionObject = 
	var circle = Circle( 5.0 )
	println( circle.area )

//_________________________________________________________
//
// 2. Use Case :: Factory Method
//
//_________________________________________________________


object Email:
	def fromString( emailString: String ) : Option[Email] =
		emailString.split('@') match
			case Array(a, b) => Some( Email( a, b) )
			case _  		 => None
			

class Email( val userName: String, val domainName: String )


def playWithFactoryMethod =
	val scalaCenterEmail = Email.fromString("scala.center@inmobi.com")

	scalaCenterEmail match
		case Some(email) 	=> println(
			s"""Registered An Email...
					Username 	: ${email.userName}
					Domain Name : ${email.domainName}

			""".stripMargin )
		case None  			=> println("Error : Email Parsing Failed...")


//_________________________________________________________

// In Java
// Human gabbar = new Human();
// Safe Code Is As Follow
// if ( gabbar != null ) gabbar.dance();
//		All Types Are Nullable By Default

// In Kotlin
// 		Non Nullable Types and Nullable Types
//		Design Towards Non Nullable Rather Than Nullability

//		Nullability You Will Bring
//			To Represent Valid Values and Non A Valid Value

// Int Type Is Non Nullable = Range Of Int
// Int? Type is Nullable Type = { Range Of Int } Union { null }

// In Scala
//		All Types Are Nullable By Default

//		Using Option Types		
//			To Represent Valid Values and Non A Valid Value
//


//_________________________________________________________________
//
//	In Scala
//
// 	Option, Some, None
//_________________________________________________________________

/* 
Option, Some, None

A note about Option, Some, and None in the code above:

Option is a data type which allows for optionality. 
		It has two cases: Some and None

The Option return type can then be used in a match/case:
	For a Some result, the match knows the returned value 
		is an instance of Email, so it can access the 
			inner username and domainName.
	
	For a None result, the match knows the returned value 
		is not an instance of Email, so it prints 
			an appropriate error message.

//_________________________________________________________

// 3. Constants static final
//		1. Prefer Enums
//		2. Seperate Constants From Class

// In Java
class Human {
	static final int singing;
	static final int dancing;
	static final int bowling;
	static final int batting;

	// Member Instances
	// Member Functions
}

// In Java
class Human {
	HumanCapability capability;
	// Member Instances
	// Member Functions
}


class HumanCapability {
	static final int singing;
	static final int dancing;
	static final int bowling;
	static final int batting;
}

// 4. static main 
		Because Class Is Building Block
		That's why static main is Workaround

// 5. Class/Type Members Initialisation
		A. Never Ever Put A State Type Level
		B. If You End Up Doing It
				Initialisation Should Be Deterministic

		class Congress {
			// Powerful God Static Member/Object
			//		Binded God Object With Type Congress
			//		Tightly Coupled State With Type

			static val gandhi = new Mahathma() // // Object = { State, Meta State }

			// Behaviour Controlled By God Object
			static def doFunctions() {

			}
		}

// 6. Utility Methods

// 7. Static Imports
// 8. To Bind Things With Class/Type
//		Behaviour
// 9. Counting Objects
//		
	class ObjectManager {
		var objectCount = 0
		//Object Creation/Destruction
		//		Counting
	}


	val manager = new ObjectManager()

// 10. Global Objects
//		Bad Idea
// 11. Communication Betwwen The Objects
// 		and so on....

	Create Communicator Classes
	With Instance Members

*/

//_________________________________________________________________
//
// EXTRACTOR OBJECT
//_________________________________________________________________

// Extractor Objects
// 		An extractor object is an object with an unapply method. 
//		Whereas the apply method is like a constructor which 
//			takes arguments and creates an object, 

//		The unapply takes an object and tries to give back the arguments. 

//		This is most often used in Pattern Matching and Partial Functions.

// BEST PRACTICE
// 		Since a value definition can use a pattern 
//				to introduce a new variable, 
//		an extractor can be used to initialize the variable, 
//			where the unapply method supplies the value.


import scala.util.Random

object CustomerID:
	def apply( name: String ) = 
		println("apply Called...")
		s"$name--${Random.nextLong()}"

	def unapply( CustomerID: String ) : Option[ String ] = 
		println("unapply Called...")
		var stringArray: Array[String] = CustomerID.split("--")
		if (stringArray.tail.nonEmpty) Some( stringArray.head ) else None


def playWithApplyUnApply =
	val gabbar = CustomerID("Gabbar Singh")

	println("Extracting....")
	val CustomerID( name ) = gabbar: @unchecked
	println( name )

	println( gabbar )

	gabbar match {
		case CustomerID( name )  => println( name )
		case _ 					 => println("CustomerID Extraction Failed...")
	}


//_________________________________________________________
// BEST PRACTICE
// The return type of an unapply should be chosen as follows:
// 		If it is just a test, return a Boolean. 
//			For instance case even().
// 		If it returns a single sub-value of type T, 
//			return an Option[T].
// 		If you want to return several sub-values T1,...,Tn, 
//			group them in an optional tuple Option[(T1,...,Tn)].
//
// 		Sometimes, the number of values to extract isn’t fixed and 
//			we would like to return an arbitrary number of values, 
//			depending on the input. 
//
//			For this use case, you can define extractors with an 
//				unapplySeq method which returns an Option[Seq[T]]. 

//		Common Examples of these patterns include 
//		Deconstructing a List using 
//			case List(x, y, z) => 
//		Decomposing a String using a regular expression Regex, such as 
//			case r(name, remainingFields @ _*) =>.
//_________________________________________________________

//_________________________________________________________________
//
// CASE CLASSES IN SCALA
//_________________________________________________________________

// Case classes are like regular classes with a few key differences 

//_________________________________________________________________
//
// Case classes Generated Methods
//_________________________________________________________________

// Since the fields of a case class are assumed to be immutable, 
//		the Scala compiler can generate many helpful methods for you:

// 1. A default toString method is generated, 
//		which is helpful for debugging.

// 2. equals and hashCode methods generated
//		using structural equality are generated, 
//		allowing you to use instances of case classes in Maps.

// 3. A copy method is generated in the class, which is very useful 
//		To create modified copies of an instance.

// 4. An unapply method is generated, which allows you to 
//		perform pattern matching on a case class 
//		(that is, case Person(n, r) => ...).

//_________________________________________________________________
//
// READ JAVA OBJECT CLASS SPECIFICICATION
//	
// 		Respect equality, hashcode and clone contract
// 		https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html#equals-java.lang.Object-
//_________________________________________________________________


// class Book( val name: String, val isbn: String ) {
// 	override def toString() = s"Book($name, $isbn)"
// }

case class Book( name: String, isbn: String )

// It is possible to use vars in case classes but this is discouraged.
case class Message(sender: String, recipient: String, var body: String)

def playWithCaseClasses = 
	
	val impatient1 = Book("Scala For Impatient", "999-8989389438")
	val impatient2 = Book("Scala For Impatient", "999-8989389438")

	// println( impatient.name )
	// println( impatient.isbn )
	println( impatient1 ) // impatient.toString()
	println( impatient2 ) // impatient.toString()

	// Book(Scala For Impatient,999-8989389438)

	println( impatient1 == impatient2 ) // impatient1.equals( impatient2 )

	val scalaImpatient1 = new Book("Scala For Impatient!", "978-0486282000")
	println( scalaImpatient1)

	val message1 = Message("guillaume@quebec.ca", "jorge@catalonia.es", "Ça va ?")
	println( message1 )

	println(message1.sender)  // prints guillaume@quebec.ca
	// message1.sender = "travis@washington.us"  // this line does not compile
	//	You can’t reassign message1.sender because 
	//		it is a val (i.e. immutable). 

	println(message1.body)
	message1.body = "How are you doing?"
	println(message1.body)

	//___________________________________________
	// Equality Test
	val message2 = Message("jorge@catalonia.es", "guillaume@quebec.ca", "Com va?")
	val message3 = Message("jorge@catalonia.es", "guillaume@quebec.ca", "Com va?")

	println( message2 )
	println( message3 )

	val messagesEqual = message2 == message3  // true
	println( messagesEqual )

	//___________________________________________

	val message4 = Message("jorge@catalonia.es", "guillaume@quebec.ca", "How are you?")
	val message5 = message4.copy()

	println( message4 )
	println( message5 )

	message4.body = "Good Evening!!!"
	println( message4 )
	println( message5 )

	val message6 = message4.copy("gabbar@gmail.com", "thakur@gmai.com")
	println( message4 )
	println( message6 )


//_________________________________________________________________
//
//
// Case Classes
// Support for Functional Programming
//
//_________________________________________________________________

// Case classes support Functional Programming (FP):
//
// In FP, you try to avoid mutating data structures. 
//		It thus makes sense that constructor fields default to val. 
//
// Since instances of case classes can’t be changed, they can 
//		Easily be shared without fearing mutation or race conditions.

// Update As You Copy
// 		Instead of mutating an instance, you can use the copy method as 
//			a template to create a new (potentially changed) instance. 
// 			This process can be referred to as “update as you copy.”

// Auto-generated unapply Method
// 		Having an unapply method auto-generated for you also 
//		lets case classes be used in advanced ways with pattern matching.
// 				Case objects

// Case Object
// 		Case objects are to objects what Case Classes are to Classes: 
//			They provide a number of automatically-generated methods to 
//				make them more powerful. 
//			They’re particularly useful whenever you need a singleton object that 
//				needs a little extra functionality, 
//					such as being used with pattern matching 
//					in match expressions.


//_________________________________________________________

enum Color:
	case Red, Green, Blue, Yellow, Orange

// def getStringForColor( color : Color): Unit = 
def getStringForColor( color : Color): String = 
	color match {
		case Color.Red 		=> "Red Color"
		case Color.Green  	=> "Green Color"
		case Color.Blue		=> "Blue Color"
		case _				=> "Unknown Color"
	}

def getStringForColorAgain( color : Color): String = 
	color match {
		case Color.Red 		=> "Red Color"
		case Color.Green  	=> "Green Color"
		case Color.Blue		=> "Blue Color"
		case _				=> throw Exception("Unknown Color")
		// case _				=> "Unknown Color"
	}


def playWithColor: Unit = 
	println( getStringForColor( Color.Red ) ) 
	println( getStringForColor( Color.Green ) ) 
	println( getStringForColor( Color.Blue ) ) 

	println( getStringForColorAgain( Color.Red ) ) 
	println( getStringForColorAgain( Color.Green ) ) 
	println( getStringForColorAgain( Color.Blue ) ) 

//_________________________________________________________

// trait Expr
// class Num(val value: Int) extends Expr
// class Sum(val left: Expr, val right: Expr) extends Expr 

def eval(e: Expr) : Int = {
	// Type of e Is Expr

	// Smart Type Check
	// e is Num Is Checking Type Num
	// 		If True Then Type Cast e To Num Type
	if e.isInstanceOf[Num] then {
		val ee = e.asInstanceOf[Num]
		// Type of e Will Be Num
		return ee.value
	} 

	// Type of e Is Expr
	if e.isInstanceOf[Sum] then {
		// Type of e Will Be Sum
		val ee = e.asInstanceOf[Sum]
		return eval(ee.left) + eval(ee.right)
	}

	throw IllegalArgumentException("Unknown Expression")
}

def playWithEval = {
	// 100 + 200
	println( eval( Sum( Num(100), Num(200) ) ) )

	// (100 + 200) + 99
	println( eval(Sum(Sum(Num(100), Num(200)), Num(99))))
}

//_________________________________________________________________

def evalAgain(e: Expr) : Int = {
	// return if e.isInstanceOf[Num] then {
	if e.isInstanceOf[Num] then {
		val ee = e.asInstanceOf[Num]
		// Type of e Will Be Num
		ee.value
	} else if e.isInstanceOf[Sum] then {
		// Type of e Will Be Sum
		val ee = e.asInstanceOf[Sum]
		evalAgain(ee.left) + eval(ee.right)
	} else {
		throw IllegalArgumentException("Unknown Expression")
	}
}

def playWithEvalAgain = {
	// 100 + 200
	println( evalAgain( Sum( Num(100), Num(200) ) ) )

	// (100 + 200) + 99
	println( evalAgain(Sum(Sum(Num(100), Num(200)), Num(99))))
}

//_________________________________________________________________

// Theorem
// Type System: Expr, Num and Sum

// Abstract Type Expr
sealed trait Expr
// Type Num and Sum
class Num(val value: Int) extends Expr
class Sum(val left: Expr, val right: Expr) extends Expr 
class Sub(val left: Expr, val right: Expr) extends Expr 

// Program : Proof
def evaluate(e: Expr) : Int = e match {
	case e: Num 	=> 	e.value 
	case e: Sum 	=> 	evaluate(e.left) + eval(e.right)
	// case _ 			=> 	throw IllegalArgumentException("Unknown Expression")
}

def playWithEvaluate = {
	// 100 + 200
	println( evaluate( Sum( Num(100), Num(200) ) ) )

	// (100 + 200) + 99
	println( evaluate(Sum(Sum(Num(100), Num(200)), Num(99))))
}


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
/*
enum MusicPlayerState {
	case PAUSE
	case START
	case PLAYING
	case STOPPED
}

class MusicPlayer {
	val currentPlayingSong : String = null
	val state : State = MusicPlayerState.PAUSE 
	val currentVolume : Int = 0
	val powerOn : Bool = true

	def playSong( name: Song ) {}
	def increaseVolume( value: Int) {}
	def decreaseVolume( value: Int) {}
	def stopSong()
}

def playWithMusicPlayer = 	

	val musicPlayer1 = MusicPlayer()

	val musicPlayer2 = MusicPlayer( 
		"Ye Dil Maange More", 
		MusicPlayerState.PLAYING,
		10,
		false
	)
*/


//_________________________________________________________

enum ColorAgain(val rgb: Int):
	case Red   extends ColorAgain(0xFF0000)
	case Green extends ColorAgain(0x00FF00)
	case Blue  extends ColorAgain(0x0000FF)

// ____________________________________________________________

// Creating Type Message
sealed trait Message1

case class PlaySong( name: String ) extends Message1
case class IncrementVolume( amount: Int ) extends Message1
case class DecreaseVolume( amount: Int ) extends Message1
case object StopPlaying extends Message1

def playSong( name: String ) 			= println(f"$name Song Started Playing...")
def changeVolume( amount : Int )	= println(f"Changing Volume: $amount")
def stopPlaying() 								= println("Stop Playing Song...")

def handleMessages( message: Message1 ) : Unit = message match {
	case PlaySong( name ) 				=> playSong( name )
	case IncrementVolume( amount )		=> changeVolume( amount )
	case DecreaseVolume( amount )		=> changeVolume( amount )
	case StopPlaying 			    => stopPlaying()
	// case _ 								=> throw Exception("IllegalArgumentException")
}

def playWithCaseClassesAndObject = 
	handleMessages( PlaySong("Chaiyaan Chaiyaaannn!!!") )	
	handleMessages( IncrementVolume( 10 ) )
	handleMessages( DecreaseVolume( 4 ) )
	handleMessages( StopPlaying )

// [warn] ./05ScalaClassesMore.scala:656:50
// [warn] match may not be exhaustive.
// [warn] 
// [warn] It would fail on pattern case: StopPlaying
// [warn] def handleMessages( message: Message1 ) : Unit = message match {
// [warn]                                                  ^^^^^^^

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

@main
def scalaClassesMore(): Unit = {
	println("\nFunction: playWithSingleton")
	playWithSingleton

	println("\nFunction: playWithCompanionObject")
	playWithCompanionObject

	println("\nFunction: playWithFactoryMethod")
	playWithFactoryMethod

	println("\nFunction: playWithApplyUnApply")
	playWithApplyUnApply

	println("\nFunction: playWithCaseClasses")
	playWithCaseClasses

	println("\nFunction: playWithCaseClassesAndObject")
	playWithCaseClassesAndObject

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}


