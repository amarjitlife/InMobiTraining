

// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!

val soemthingOutside = 999

// Nested Class
// CANNOT Assess Outer Class Context, Inside Inner Class
class Car1(val carName: String) { // Also A Lambda
	val something = "Hello"

    fun doSomething() { // Member Function Is Also Lambda
        println(something)
    }

    class Engine(val engineName: String) { //

        override fun toString(): String {
            // Error cannot see outer scope, Hence Cann't Access carName
            return "$engineName in a $carName" 
            // return "$engineName"
        }
    }
}

//______________________________________________________________


// Inner Class
// Can Assess Outer Class Context, Inside Inner Class
class Car2(val carName: String) { // Outer Class
	val something = "Hello"

    inner class Engine(val engineName: String) { // Inner Class
        override fun toString(): String {
            return "$engineName engine in a $carName"
        }
    }
}   

// Nested and Inner classes
fun playWithNestedAndInnerClasses() {
    val mazda1 = Car1("mazda")
    val mazdaEngine1 = Car1.Engine("rotary")
    println(mazdaEngine1) // > rotary engine in a mazda

    val mazda = Car2("mazda")
    val mazdaEngine = mazda.Engine("rotary")
    println(mazdaEngine) // > rotary engine in a mazda
}

//______________________________________________________________


fun playWithNullabilityAndNonNullability() {
    
    // String, Int, Float, Double etc... Are NON NULLABLE Types
    //      i.e. You CAN'T Assign null Value To These Types Variables
    var name: String = "Alice Carol"
    var age: Int = 30
    var occupation: String = "Software Engineer"

    println("$name $age $occupation")
    name = "Alice Carol Mcmillan"
    age = 40
    age = age + 1
    occupation = "Sr. Software Engineer"
    println("$name $age $occupation")   

    // Following 3 Lines Of Code Will Give Compilation Error
    // name = null          // error: null can not be a value of a non-null type String
    // age = null           // error: null can not be a value of a non-null type Int
    // occupation = null    // error: null can not be a value of a non-null type String

    // Nullabe Types Are Also Called Optional Types
    // String?, Int?, Float?, Double? etc... Are NULLABLE Types
    //      i.e. You CAN Assign null Value To These Types Variables
    var name1: String? = "Alice Carol"
    var age1: Int? = 30
    var occupation1: String? = "Software Engineer"

    println("$name1 $age1 $occupation1")
    name1 = "Alice Carol Mcmillan"
    age1 = 40
    age1 = age1 + 1
    occupation1 = "Sr. Software Engineer"
    println("$name1 $age1 $occupation1")    

    name1 = null        
    age1 = null         
    occupation1 = null  
    println("$name1 $age1 $occupation1")
}

//______________________________________________________________

fun playWithNullabilityAndNonNullabilityAgain() {
    var authorName: String? = "Joe Howard"
    var authorAge: Int? = 24

    println(authorName)
    println(authorAge)

    // error: operator call corresponds to a dot-qualified call 
    // 'authorAge.plus(1)' which is not allowed on a nullable receiver 'authorAge'.
    // val ageAfterBirthday = authorAge + 1     // authorAge.plus(1)

    // error: only safe (?.) or 
    // non-null asserted (!!.) calls are allowed on a 
    // nullable receiver of type Int?
    
    // ?. is Safe Calls Operator

    val ageAfterBirthday0 = authorAge?.plus(1)

    println("After their next birthday, author will be $ageAfterBirthday0")

    // !! Not Recommended,  It's Used In Rarest Rare Scenarios 
    val ageAfterBirthday1 = authorAge!! + 1    
    println("After their next birthday, author will be $ageAfterBirthday1")

    authorAge = null
    println("After two birthdays, author will be $authorAge")
    // val ageAfterBirthday2 = authorAge!! + 1    

    var nonNullableAuthor: String = ""
    var nullableAuthor: String? = ""

    if (authorName != null) {
        nonNullableAuthor = authorName
    } else {
        nullableAuthor = authorName
    }

    println(nonNullableAuthor)
    println(nullableAuthor)

    // Nullable Types Members Cann't Be Accessed Using . Operator
    //      Use ?. or !! Operator

    // error: only safe (?.) or non-null asserted (!!.) calls are allowed 
    // on a nullable receiver of type String?
    // var nameLength = authorName.length
 
    // ?. is Safe Calls Operator
    var nameLength = authorName?.length
    // Above Line Of Code Is Equvalent To Following Line Of Code
    //      if (authorName != null) authorName else null
    println("Author's name has length $nameLength.")

    val nameLengthPlus5 = authorName?.length?.plus(5)
    println("Author's name length plus 5 is $nameLengthPlus5.")
}


// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!


fun playWithCollectionNullability() {
    // Nullability and Collection Types

    // Nullable List Can Store Int Type Data
    // Can't Store null Inside Collection
    var nullableList: List<Int>? = listOf(1, 2, 3, 4)
    println( nullableList?.get(0) )
    nullableList = null
    println(nullableList)

    // Nullable List Can Store Int Type Data
    // Can't Store null Inside Collection
    // var nullableList1: List<Int>? = listOf(1, 2, 3, 4, null, 5)
    // nullableList1 = null
    // println(nullableList1)

    // Non-Nullable List Can Store Int? Type Data 
    // i.e Can Store null Inside Collection
    var listOfNullables: List<Int?> = listOf(1, 2, null, 4)
    // listOfNullables = null // Error: Null can not be a value of a non-null type
    println(listOfNullables)

    // Nullable List Can Store Int? Type Data
    // i.e Can Store null Inside Collection
    var nullableListOfNullables: List<Int?>? = listOf(1, 2, null, 4)
    println( nullableListOfNullables?.get(0) )
    nullableListOfNullables = null
    println(nullableListOfNullables)
}



// _____________________________________________________

// DESIGN PRINCIPLES
//      Design Towards Non Nullability Rather Than Nullabiliy
//      Bring Nullabiliity In System Design Based On Very Specific Design Goald
//      Handle Nullability As Early As Possible
//      Resist Temptation To Propogate Nullability

// _____________________________________________________

// Employee Class Having Two Properties
//      name Property Is of String Type And Non Nullable
//      manager Property Is of Employee Type And Nullable

class Employee(val name: String, val manager: Employee?)


fun getManagerName(employee: Employee) : String? {
    //  error: only safe (?.) or non-null asserted (!!.) 
    //  calls are allowed on a nullable receiver of type Employee?
    // return employee.manager.name 
    
    // error: type mismatch: inferred type is String? but String was expected
    
    // If Any Part In Expression Become null Then Whole Expression Becomes null
    // You Cann't Return null From Function, If Return Type Is Non Nullable
    //      Make Return Type Of Function Nullable, To Return null From Function 
    return employee.manager?.name 
}

fun plaWithEmployeeManager() {
    val ceo         = Employee("Da Boss", null)
    val ashwaraya   = Employee("Ashwaraya", ceo)

    println( getManagerName(ashwaraya) )
    println( getManagerName(ceo) )
}

// _____________________________________________________
// _____________________________________________________


/*
kotlinc -include-runtime Hello.kt -d hello.jar
java -jar nature.jar
*/

//_______________________________________________________

// Function Type
//      (Int, Int) -> Int
fun sum( a: Int, b: Int ): Int  = a + b
fun sub( a: Int, b: Int ): Int  = a - b

// Higher Order Function
//      Functions Which Takes And/Or Returns Functions

// Polymorphic Function
//      Mechanism : Passing A Behaviour To Behaviour

// Function Type
//      (Int, Int, (Int, Int) -> Int) -> Int
fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
    return operation( a, b )
}

fun playWithCalculator() {
    val a = 50
    val b = 20
    var result: Int = 0

    result = calculator( a, b, ::sum ) // Configuring with ::sum
    println("Result : $result")

    result = calculator( a, b, ::sub ) // Configuring with ::sum
    println("Result : $result")

    // Lambda
    //      Anonmous Functions
    val sumLambda: (Int, Int) -> Int  = { a: Int, b: Int -> a + b }
    result = calculator( a, b, sumLambda ) // Configuring with sumLambda
    println("Result : $result")

    // Function Type (Int, Int) -> Int
    val subLambda = { a: Int, b: Int -> a - b }
    result = calculator( a, b, subLambda ) // Configuring with subLambda
    println("Result : $result")

    result = calculator( a, b, { a: Int, b: Int -> a * b } ) // Configuring with subLambda
    println("Result : $result")

    // Trailing Lamba Syntax
    result = calculator( a, b ) { a: Int, b: Int -> a * b } // Configuring with subLambda
    println("Result : $result")

    result = calculator( a, b ) { 
        a: Int, b: Int -> a * b 
    } // Configuring with subLambda
    println("Result : $result")

    // (Int, Int) -> Int
    val something = sum

    //      (Int, Int, (Int, Int) -> Int) -> Int

    val somethingAgain = calculator

}

//_______________________________________________________

// ( (Int, Int) -> Int ) -> Unit
fun twoAndThree(operation: (Int, Int) -> Int) {
    val result = operation(2, 3)
    println("The result is $result")
}

fun callingFunctionsPassedAsArguments() {
    twoAndThree { a, b -> a + b }
    twoAndThree { a, b -> a * b }
}

//_______________________________________________________

data class Person(val name: String, val age: Int)

fun findTheMax(people: List<Person> ) {
    var max = 0
    var theMaximum: Person? = null

    for (person in people) {
        if ( person.age > max) {
            max = person.age
            theMaximum = person
        }
    }
    println(theMaximum)
}

fun playWithTheMax() {
    val people = listOf(Person("Alice", 29), Person("Bob", 31))
    findTheMax(people)
}

//_______________________________________________________

fun String.filter(predicate: (Char) -> Boolean): String {
    val sb = StringBuilder()
    for (index in 0 until length) {
        val element = get(index)
        if (predicate(element)) sb.append(element)
    }
    return sb.toString()
}

fun callingFunctionsPassedAsArguments1() {
    println("ab1c".filter { it in 'a'..'z' })
}

//_______________________________________________________


fun <T> Collection<T>.joinToStringDefault(
        separator: String = ", ",
        prefix: String = "",
        postfix: String = "",
        transform: (T) -> String = { it.toString() }
): String {
    val result = StringBuilder(prefix)

    for ((index, element) in this.withIndex()) {
        if (index > 0) result.append(separator)
        result.append(transform(element))
    }

    result.append(postfix)
    return result.toString()
}

fun joinToStringDefaultFunction() {
    val letters = listOf("Alpha", "Beta")

    //error: cannot choose among the following candidates 
    // without completing type inference: 
    println(letters.joinToStringDefault())

    println(letters.joinToStringDefault { it.lowercase() } )
    println(letters.joinToStringDefault(separator = "! ", postfix = "! ",
           transform = { it.lowercase() }))
}

//_______________________________________________________

enum class Delivery { STANDARD, EXPEDITED }

class Order(val itemCount: Int)

fun getShippingCostCalculator(delivery: Delivery): (Order) -> Double {
    if (delivery == Delivery.EXPEDITED) {
        return { order -> 6 + 2.1 * order.itemCount }
    }

    return { order -> 1.2 * order.itemCount }
}

fun returningFunctionsFromFunctions() {
    val calculator =
        getShippingCostCalculator(Delivery.EXPEDITED)
    println("Shipping costs ${calculator(Order(3))}")
}


//_______________________________________________________

data class Person1(
    val firstName: String,
    val lastName: String,
    val phoneNumber: String?
)

class ContactListFilters {
    var prefix: String = ""
    var onlyWithPhoneNumber: Boolean = false

    fun getPredicate(): (Person1) -> Boolean {
        val startsWithPrefix = { p: Person1 ->
            p.firstName.startsWith(prefix) || p.lastName.startsWith(prefix)
        }
        if (!onlyWithPhoneNumber) {
            return startsWithPrefix
        }
        return { startsWithPrefix(it)
                    && it.phoneNumber != null }
    }
}

fun returningFunctionsFromFunctions1() {
    val contacts = listOf(Person1("Dmitry", "Jemerov", "123-4567"),
                          Person1("Svetlana", "Isakova", null))
    val contactListFilters = ContactListFilters()
    with (contactListFilters) {
        prefix = "Dm"
        onlyWithPhoneNumber = true
    }
    println(contacts.filter(
        contactListFilters.getPredicate()))
}

// Function: returningFunctionsFromFunctions1
// [Person1(firstName=Dmitry, lastName=Jemerov, phoneNumber=123-4567)]

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

fun main() {
    println("\nFunction: playWithCalculator")
    playWithCalculator()

    println("\nFunction: returningFunctionsFromFunctions1")
    returningFunctionsFromFunctions1()

    // println("\nFunction: ")  
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")  
}



import java.util.Random

//_____________________________________________________

// E Is Type Place Holder
// MutableStack Is Generic Type i.e. Template

//  Generics Are Templates Programming
//      In Mathematics It's Callled Parameterised Types
//      Write Code To Generate Code
//      Compile Time Polymorphism

class MutableStack<E>( vararg items: E ) {              
    private val elements = items.toMutableList()
    fun push(element: E) = elements.add(element)        
    fun peek(): E = elements.last()                     
    fun pop(): E = elements.removeAt(elements.size - 1)
    fun isEmpty() = elements.isEmpty()
    fun size() = elements.size
    override fun toString() = "MutableStack(${elements.joinToString()})"
}


// // Compiler Generatged Code On Demand Basis
// //       Based On The Usage
// class MutableStack<Int>( vararg items: Int ) {              // 1
//   private val elements = items.toMutableList()
//   fun push(element: Int) = elements.add(element)        // 2
//   fun peek(): Int = elements.last()                     // 3
//   fun pop(): Int = elements.removeAt(elements.size - 1)
//   fun isEmpty() = elements.isEmpty()
//   fun size() = elements.size
//   override fun toString() = "MutableStack(${elements.joinToString()})"
// }


// // Compiler Generatged Code On Demand Basis
// //       Based On The Usage
// class MutableStack<String>( vararg items: String ) {              // 1
//   private val elements = items.toMutableList()
//   fun push(element: String) = elements.add(element)        // 2
//   fun peek(): String = elements.last()                     // 3
//   fun pop(): String = elements.removeAt(elements.size - 1)
//   fun isEmpty() = elements.isEmpty()
//   fun size() = elements.size
//   override fun toString() = "MutableStack(${elements.joinToString()})"
// }

fun playWithMutableStack() {
    // Type Inferred and Substitued At Type Place Holder <E> At Compile Time
    val stackInts = MutableStack<Int>( 10, 20, 30 )
    println( stackInts.size() ) 
    stackInts.push( 100 )
    stackInts.push( 200 )
    println( stackInts.size() ) 
    println( stackInts.pop() )  

    val stackStrings = MutableStack<String>( "Ding", "Dong" )
    println( stackStrings.size() ) 
    stackStrings.push( "Ting" )
    stackStrings.push( "Tong" )
    println( stackStrings.size() ) 
    println( stackStrings.pop() )   
}

//_____________________________________________________


class Temperature(var tempInCelsius: Float)

// Extension Properties 
var Temperature.tempInFahrenheit: Float
    get() = (tempInCelsius * 9 / 5) + 32
    set(value) {
        tempInCelsius = (value - 32) * 5 / 9
    }

fun playWithExtensionProperties() {
    val temp = Temperature(32f)
    println( temp.tempInFahrenheit )

    temp.tempInFahrenheit = 90f
    println( temp.tempInCelsius )
}

//_____________________________________________________

// Generic Extention Property

val <T> List<T>.penultimate: T
    get() = this[ size - 2 ]


fun playWithGenericProperty() {
    val list = listOf( 10, 20, 30, 40)
    println( "Value : ${ list.penultimate }")

    val listAgain = listOf( "Ding", "Dong", "Ting", "Tong")
    println( "Value : ${ listAgain.penultimate }")
}

//_____________________________________________________

open class Animal( val type : String  ) 
open class Pet( val name : String, type: String ) : Animal( type )

class Cat( name : String, type: String ) : Pet( name, type ) 
open class Dog( name : String, type: String ) : Pet( name, type ) 
class GermanShaperd( name : String, type: String ) : Dog( name, type ) 

// Polymorpic Functions
//      Using Mechanism: Passing Parent Type From Hierarcy
//          Can Pass Pet and Pet Child Types
fun chooseFavoriteNonGeneric( pets: List<Pet> ) : Pet {
    val random = Random()
    val favorite = pets[ random.nextInt( pets.size ) ]
    println("${favorite.name} is the favorite")
    return favorite
}

// fun <T> chooseFavorite( pets: List<T> ): T {
//       error: unresolved reference 'name'

// Polymorphic Function
//      Compile Time Polymorphism
//      Compiler Will Generate Copy Code After 
///         Inferrering/Subtituting Type At Compile Time

// Type Bounds
//      T Can Be Any Type Whose Super Type Is Pet
//      Or Any Sub Type Of Pet
fun <T : Pet> chooseFavorite(pets: List<T> ): T {
    val random = Random()
    val favorite = pets[ random.nextInt( pets.size ) ]
    println("${favorite.name} is the favorite")
    return favorite
}

fun playWithChooseFavorite() {
    val catsAgain: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
    val favoriteAgain = chooseFavoriteNonGeneric( catsAgain )
    println( "Favorite Name : ${ favoriteAgain.name }" )

    val dogs1: List<Dog> = listOf( Dog( "Indian Dog!", "Dog"), Dog("Hound", "Dog"),
                                Dog("BitBull", "Dog"), Dog("Pug", "Dog"),
                                GermanShaperd("German GermanShaperd", "Dog") )
    val favoriteOnceAgain = chooseFavoriteNonGeneric( dogs1 )
    println( "Favorite Name : ${ favoriteOnceAgain.name }" )

    val cats1: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
    val favorite1 = chooseFavorite( cats1 )
    println( "Favorite Name : ${ favorite1.name }" )

    val dogs2: List<Dog> = listOf( Dog( "Indian Dog!", "Dog"), Dog("Hound", "Dog"),
                                Dog("BitBull", "Dog"), Dog("Pug", "Dog"),
                                GermanShaperd("German GermanShaperd", "Dog") )
    val favorite2 = chooseFavorite( dogs2 )
    println( "Favorite Name : ${ favorite2.name }" )

    val animals: List<Animal> = listOf( Animal("Fish"), Animal("Bird"), Animal("Mammal") )
    for (animal in animals) println( animal.type )

    // error: type mismatch: inferred type is Animal but Pet was expected
    // val favoriteAgain2 = chooseFavorite( animals )
    // print( favoriteAgain2 )
}

//_____________________________________________________

// Boundless Generic Function
//      i.e. T Place Holder Can Be Substited With Any Type T
fun <T> equalsResult( first: T, second : T ) : Boolean  {
    return first == second
}

fun playWithEqualResults() {
    val first0 = 10
    val second0 = 100
    println( equalsResult( first0, second0 ) )

    val first1 = 10.90
    val second1 = 100.90
    println( equalsResult( first1, second1 ) )

    val first2 = Cat("Catie", "Cat")
    val second2 = Cat("Batie", "Cat")
    println( equalsResult( first2, second2 ) )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// error: unresolved reference. None of the following candidates is 
//      applicable because of a receiver type mismatch:
// fun < T > max( first: T, second : T ) : T {
fun < T : Comparable<T> > max( first: T, second : T ) : T {
    return if ( first > second ) first else second
}

fun playWithGenericMax() {
    val maxValue0 = max( "Kotlin", "Java" )
    println( maxValue0 )

    val maxValue1 = max( 900, 100 )
    println( maxValue1 )

    val maxValue2 = max( 90.90, 100.100 )
    println( maxValue2 )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Mutiple Type Parameters viz. T and U
fun < T : Pet, U : Human > chooseFavoriteMultiples( pets: List<T>, owners : List<U> ) : T {
    val random = Random()
    val owner = owners[ random.nextInt( owners.size ) ]
    val favorite = pets[ random.nextInt( pets.size ) ]

    println("${ favorite.name } is ${ owner.name } Favorite")
    return favorite
}

fun playWithChooseFavoriteMultiples() {
    val cats: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
    val owners: List<Owner> = listOf( Owner("Himnanshu"), Owner("Shubra") )

    val favorite = chooseFavoriteMultiples( cats, owners )
    println( "Favorite Name : ${ favorite.name }" )
}

//_______________________________________________________________

fun <T> chooseFavoriteWhere(pets: List<T>): T where T : Pet {
    val random = Random()
    val favorite = pets[random.nextInt(pets.size)]
    println("${favorite.name} is the favorite")
    return favorite
}

// Following Both Signatures Are Equivalent!
// fun <T : Pet, U : Human> chooseFavoriteMultiplesWhere(pets: List<T>, owners: List<U>): T {
fun <T, U> chooseFavoriteMultiplesWhere(pets: List<T>, owners: List<U>): T where T : Pet, U : Human {
    val random = Random()
    val owner = owners[random.nextInt(owners.size)]
    val favorite = pets[random.nextInt(pets.size)]
    println("${favorite.name} is ${owner.name}'s favorite")
    return favorite
}

// “If a type parameter has multiple constraints, 
// they all need to be placed in the ‘where’ clause” 

// // fun <T : Animal> chooseFavorite(pets: List<T>): T 
//      where T : Named {
//       /* ... */ 
// } 

//_______________________________________________________________

// Default Constraint
// If you don’t specify a constraint, the default constraint will be Any?.

fun <T> chooseFavoriteDefault(things: List<T>) : T { 
    /* ... */ 
}

// is the exactly the same as
fun <T : Any?> chooseFavoriteDefaultAgain(things: List<T>) : T { 
    /* ... */ 
}


// Nullable Constraints
// If you want to specify a nullable type for the constraint, 
// it’ll work as expected:

fun <T : Pet?> chooseFavoriteNullablePet(pets: List<T>): T {
    val favorite = pets[random.nextInt(pets.size)]
    println("${favorite?.name ?: "Nobody"} is the favorite")
    return favorite
}

// Any Non-Null
// Naturally, if you want to accept any type that isn’t null, 
// you’d just use Any as the constraint:
fun <T : Any> chooseFavoriteNonNullableAny(things: List<T>): T { 
    /* ... */ 
}

fun playWithChooseFavoriteNullable() {
    val maybeCats: List<Cat?> = listOf(Cat("Whiskers"), null, Cat("Rosie"))
    val favorite: Cat? = chooseFavorite(maybeCats)

    // Just remember that the ? goes on the type constraint, 
    // not the type parameter references. 
    // In other words, in this example, you 
    // wouldn’t specify List<T?> or return T?.
}


//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun main( ) {
    println("\nFunction : playWithChooseFavorite")
    playWithChooseFavorite()

    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
}



