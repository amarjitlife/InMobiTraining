
//_______________________________________________________
//
// DAY 01+02
//_______________________________________________________

ASSIGNMENTS A1: Scala REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Scala Code Done In Class

ASSIGNMENTS A2: READING AND EXPLORATION ASSIGNMENTS
	Study Following Scala Chapters
		Chapter 01: The Basics (A1)
		Chapter 02: Control Structures and Functions (A1)
		Chapter 03: Arrays (A1)
		Chapter 04: Maps and Tuples (A1)
	Reference: Scala For Impatient, 3rd Edition, Cay Hortsman

ASSIGNMENTS A3: READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter 02 : Object-Oriented Programming
	Reference: Java For Impatient, Cay Hortsman

//_______________________________________________________
//
// DAY 03
//_______________________________________________________

ASSIGNMENTS A1: Scala REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Scala Code Done In Class

ASSIGNMENTS A2: READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter 04: Classes

	Reference: Scala For Impatient, 3rd Edition, Cay Hortsman


//_______________________________________________________
//
// DAY 04
//_______________________________________________________

ASSIGNMENTS A0: READING AND EXPLORATION ASSIGNMENTS
	Study Following Scala Chapters
		Chapter 01: The Basics (A1)
		Chapter 02: Control Structures and Functions (A1)
		Chapter 03: Arrays (A1)
		Chapter 04: Maps and Tuples (A1)
	Reference: Scala For Impatient, 3rd Edition, Cay Hortsman

ASSIGNMENTS A1: Scala REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice All Code + Scala Code Done In Class

ASSIGNMENTS A2: READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter : Classes
		Chapter : Interfaces And Lambdas
	Reference: Java For Impatient, 3rd Edition, Cay Hortsman

ASSIGNMENTS A3: EXPLORATION ASSIGNMENTS
	https://medium.com/@AlexanderObregon/the-purpose-and-mechanics-of-escape-analysis-in-the-jvm-f02c17860b8c
	https://ondrej-kvasnovsky.medium.com/escape-analysis-in-the-jvm-cd08e794b8df

//_______________________________________________________
//
// DAY 05+06
//_______________________________________________________

ASSIGNMENTS A0: READING AND EXPLORATION ASSIGNMENTS
	Study Following Scala Chapters
		Chapter 05: Classes
	Reference: Scala For Impatient, 3rd Edition, Cay Hortsman

ASSIGNMENTS A1: Scala REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice All Code + Scala Code Done In Class

ASSIGNMENTS A2: READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter : Classes
		Chapter : Interfaces And Lambdas
	Reference: Java For Impatient, 3rd Edition, Cay Hortsman

ASSIGNMENTS A3: EXPLORATION ASSIGNMENTS
	https://medium.com/@AlexanderObregon/the-purpose-and-mechanics-of-escape-analysis-in-the-jvm-f02c17860b8c
	https://ondrej-kvasnovsky.medium.com/escape-analysis-in-the-jvm-cd08e794b8df

//_______________________________________________________
//
// DAY 07
//_______________________________________________________

ASSIGNMENTS A0: READING AND EXPLORATION ASSIGNMENTS
	Study Following Scala Chapters
		Chapter 05: Classes
	Reference: Scala For Impatient, 3rd Edition, Cay Hortsman

ASSIGNMENTS A1: Scala REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice All Code + Scala Code Done In Class

ASSIGNMENTS A2: READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter : Classes
		Chapter : Interfaces And Lambdas
	Reference: Java For Impatient, 3rd Edition, Cay Hortsman

ASSIGNMENTS A3: EXPLORATION ASSIGNMENTS
	https://refactoring.guru/design-patterns/factory-method
	Implement Dialog Use Case Example In Scala
		Create Factory Methods

//_______________________________________________________
//
// DAY 08-09
//_______________________________________________________

ASSIGNMENTS A0: READING AND EXPLORATION ASSIGNMENTS
	Study Following Scala Chapters
		Chapter 01 To Chapter 10
	Reference: Scala For Impatient, 3rd Edition, Cay Hortsman

ASSIGNMENTS A1: Scala REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice All Code + Scala Code Done In Class


//_______________________________________________________
//
// DAY 10
//_______________________________________________________

ASSIGNMENTS A0: READING AND EXPLORATION ASSIGNMENTS
	Study Following Scala Chapters
		Chapter 01 To Chapter 10
	Reference: Scala For Impatient, 3rd Edition, Cay Hortsman

ASSIGNMENTS A1: Scala REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice All Code + Scala Code Done In Class

//_______________________________________________________
//
// DAY 11
//_______________________________________________________

ASSIGNMENTS A0: READING AND EXPLORATION ASSIGNMENTS
	Study Following Scala Chapters
		Chapter 12
	Reference: Scala For Impatient, 3rd Edition, Cay Hortsman

ASSIGNMENTS A1: Scala REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice All Code + Scala Code Done In Class

ASSIGNMENTS A2: Scala Experiments
	Implement Decorator Pattern Use Cases In Scala

//_______________________________________________________
//
// DAY 12+13
//_______________________________________________________

ASSIGNMENTS A0: READING AND EXPLORATION ASSIGNMENTS
	Study Following Scala Chapters

	Reference: Scala For Impatient, 3rd Edition, Cay Hortsman

		Chapter 2 Control Structures and Functions
		Chapter 3 Working with Arrays
		Chapter 4 Maps, Options, and Tuples
		Chapter 5 Classes
		Chapter 6 Objects and Enumerations
		Chapter 7 Packages, Imports, and Exports
		Chapter 8 Inheritance
		Chapter 9 Files and Regular Expressions
		Chapter 10 Traits 					[ MUST MUST ]
		Chapter 11 Operators
		Chapter 12 Higher-Order Functions  	[ MUST MUST ]
		Chapter 13 Collections 				[ MUST ]
		Chapter 14 Pattern Matching 		[ MUST ]
		Chapter 17 Type Parameters 			[ MUST MUST ]

	Reference: Functional Programming In Scala, 2nd Edition
		Chapter 03 ■ Functional data structures  		[ MUST MUST ]
		Chapter 04 ■ Handling errors without exceptions [ MUST MUST ]

ASSIGNMENTS A1: Scala REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice All Code + Scala Code Done In Class


//_______________________________________________________
//
// DAY 14-16
//_______________________________________________________

ASSIGNMENTS A0: READING AND EXPLORATION ASSIGNMENTS
	Study Following Scala Chapters

	Reference: Scala For Impatient, 3rd Edition, Cay Hortsman
		Full Book

	Reference: Functional Programming In Scala, 2nd Edition
		Chapter 03 ■ Functional data structures  		[ MUST MUST ]
		Chapter 04 ■ Handling errors without exceptions [ MUST MUST ]

ASSIGNMENTS A1: Scala REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice All Code + Scala Code Done In Class

ASSIGNMENTS A2: MODELLING ASSIGNMENTS
	https://kubuszok.com/2024/modeling-in-scala-part-1/

//_______________________________________________________
//_______________________________________________________


:: FUTURE WORK ::

		2. Programming Scala, Orielly Publication
		3. Programming In Scala, Martin Ordesky [ REFERENCE ]
		4. Structure and Interpretation of Computer Programming

//_______________________________________________________
//_______________________________________________________


www.linkedin.com/in/amarjitlife
amarjitlife@gmail.com
+91 9980 777 145 ( WhatsApp )

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________


