
//_________________________________________________________

// Scala, like Java, does not allow a class to inherit from multiple superclasses.
// Multiple inheritance works fine when you combine classes that have nothing in common.


// Java designers were so concerned about these complexities that they took a very
// restrictive approach. A class can extend only one superclass; it can implement
// any number of interfaces, but interfaces can have only abstract, static, or default
// methods, and no fields.

// Java default methods are very limited. They can call other interface methods, but
// they cannot make use of object state. It is therefore common in Java to provide
// both an interface and an abstract base class, but that just kicks the can down the
// road. What if you need to extend two of those abstract base classes?


// Scala has traits instead of interfaces. A trait can have abstract and concrete
// methods, as well as state. In fact, a trait can do everything a class does. There are
// just three differences between classes and traits:
// • You cannot instantiate a trait.
// • In trait methods, calls of the form super.someMethod 
//			are dynamically resolved.
// • Traits cannot have auxiliary constructors.

//_________________________________________________________

def playWithTraitsAsInterface =
	import java.io.*

	// Traits as Interfaces

	trait Logger :
		def log(msg: String) : Unit // An abstract method

	class ConsoleLogger extends Logger : // Use extends, not implements
		def log(msg: String) = println(msg) // No override needed

	class FileLogger extends Logger, AutoCloseable, Appendable :
		private val out = PrintWriter("/tmp/log.txt")
		def close() = { log("Closing"); out.close() }
		def log(msg: String) = append(msg + "\n")
		export out.append

	def demonstration =
		val logger = ConsoleLogger()
		val logger2 = FileLogger()
		logger2.log("Running demo")
		logger2.close()
		logger.log("Exiting demo")

	demonstration

// A Scala trait can work exactly like a Java
// interface, declaring one or more abstract methods

// Note that you need not declare the method as abstract—an unimplemented
// method in a trait is automatically abstract.

// You need not supply the override keyword when overriding an abstract method
// of a trait.

// Note
// Scala doesn’t have a special keyword for implementing a trait. You use
// the same keyword extends for forming a subtype of a class or a trait.
// If you need more than one trait, add the others using commas:

// 		class FileLogger extends Logger, AutoCloseable, Appendable :
// 				...

// Note the AutoCloseable and Appendable interfaces from the Java library. All Java
// interfaces can be used as Scala traits.
// As in Java, a Scala class can have only one superclass but any number of traits.

// Note
// You can use the with keyword instead of commas:

// class FileLoggerAgain extends Logger with AutoCloseable with Appendable


//_________________________________________________________

// DESIGIN PRINCIPLE
//		Design Towards Abstract Types Rather Than Concrete Types

//	Corollary
//		Design Towards Interfaces/Traits Rather Concrete Classes
//		Always Prefer Traits/Interfaces With Abstract Methods
//		Use Default Implementation In Traits/Interfaces In Rarest Rare Scenario
//			It Should Be Universtal Truth For Set Of Types in Domain
//		Always Interfaces Over Abstract Classes
//		Always Prefer Abstract Classes Over Concrete Classes
//		Classes Must Be Final If It's Not Meant To Be Inherited
//		Always Prefer Enums Over Classes
//		Always Prefer Sealed Classes Over Classes

// BEST PRACTICE
def playtWithTraitsWithConcreteMethods =

	// Traits with concrete methods

	trait Logger :
		def log(msg: String): Unit // Abstract Method

	trait ConsoleLogger extends Logger :
		// Default Implementation :: Hence Concrete Method
		def log(msg: String) = println(msg)

	class Account :
		protected var balance = 0.0

	class ConsoleLoggedAccount extends Account, ConsoleLogger :
		def withdraw(amount: Double) =
			if amount > balance then log("Insufficient funds")
			else balance -= amount  
		// More methods ...

	def demonstration =
		val acct = ConsoleLoggedAccount()
		acct.withdraw(100)
	
	demonstration


//_________________________________________________________

// A trait can have many utility methods that depend on a few abstract ones. 

// Scala Iterator trait that defines dozens of methods in terms of the
// abstract next and hasNext methods.

// This use of concrete and abstract methods in a trait is very common in Scala. In
// Java, you can achieve the same with default methods.


def playWithTraitsForRichInterfaces = 

	// Traits for rich interfaces

	trait Logger :
		def log(msg: String) : Unit
		def info(msg: String) = log(s"INFO: $msg") 
		def warn(msg: String) = log(s"WARN: $msg") 
		def severe(msg: String) = log(s"SEVERE: $msg")

	trait ConsoleLogger extends Logger :
		def log(msg: String) = println(msg)

	class Account :
		protected var balance = 0.0

	class ConsoleLoggedAccount extends Account, ConsoleLogger :  
		def withdraw(amount: Double) =
			if amount > balance then severe("Insufficient funds")
			else balance -= amount
		
	def demonstration = 
		val acct = ConsoleLoggedAccount() 
		acct.withdraw(100)

	demonstration

//_________________________________________________________

def playWithObjectsWithTraits = 

	import java.nio.file.*
	// Objects with traits

	trait Logger :
		def log(msg: String): Unit

	class Account :
		protected var balance = 0.0

	abstract class LoggedAccount extends Account, Logger :
		def withdraw(amount: Double) =
			if amount > balance then log("Insufficient funds")
			else balance -= amount

	trait ConsoleLogger extends Logger : 
		def log(msg: String) = println(msg)

	trait FileLogger extends Logger :
		def log(msg: String) = Files.writeString(Path.of("/tmp/log.txt"), msg + "\n", StandardOpenOption.APPEND)

	def demonstration = 
		// Objects with traits
		val acct1 	= new LoggedAccount() with ConsoleLogger
		val acct2 	= new LoggedAccount() with FileLogger

		acct1.withdraw(100)
		acct2.withdraw(100)

	demonstration

// Function: playWithObjectsWithTraits
// Insufficient funds

// can add a trait to an individual object when you construct it.

// Caution
// Note that you need the new keyword to construct an object that mixes in a
// trait. (With new, you don’t need empty parentheses to invoke the no-
// argument constructor of the class, but I am adding them for consistency.)
// You also need to use the with keyword, not a comma, before each trait.

// Let’s assume the following concrete trait:
// 	trait ConsoleLogger extends Logger :
// 		def log(msg: String) = println(msg)

// Here is how you can construct an object:
// 		val acct = new LoggedAccount() with ConsoleLogger

// Of course, another object can add in a different concrete trait:
// 		val acct2 = new LoggedAccount() with FileLogger

//_________________________________________________________

def playWithLayeredTraits = 
	// Layered traits
	trait Logger :
		def log(msg: String): Unit

	trait ConsoleLogger extends Logger :
		def log(msg: String) = println(msg)

	class Account :
		protected var balance = 0.0

	abstract class LoggedAccount extends Account, Logger :
		def withdraw(amount: Double) =
			if (amount > balance) log("Insufficient funds")
			else balance -= amount  
		// More methods ...

	trait TimestampLogger extends ConsoleLogger :
		override def log(msg: String) =
			super.log(s"${java.time.Instant.now()} $msg")

	trait ShortLogger extends ConsoleLogger :
		override def log(msg: String) =
			super.log(
				if msg.length <= 15 then msg
				else s"${msg.substring(0, 14)}…")

	def demonstration = 
		// To see how the order matters, compare the following two examples:
		val acct1 = new LoggedAccount() with TimestampLogger with ShortLogger
		val acct2 = new LoggedAccount() with ShortLogger with TimestampLogger
		acct1.withdraw(100) 
		acct2.withdraw(100)
	
	demonstration


// can add, to a class or an object, multiple traits 
//	that invoke each other starting with the last one. 

// This is useful when you need to transform a value in stages.

// With traits, super.log does not have the same meaning as it does with classes.
// Instead, super.log calls the log method of another trait, which depends on the
// order in which the traits are added.

// For simple mixin sequences, 
// The “back to front” rule will give you the right intuition

// Note
// With traits, you cannot tell from the source code which method is invoked
// by super.someMethod. The exact method depends on the ordering of the
// traits in the object or class that uses them. This makes super far more
// flexible than in plain old inheritance.

// Note
// If you want to control which trait’s method is invoked, you can specify it in
// brackets: super[ConsoleLogger].log(...). The specified type must be an
// immediate supertype; you can’t access traits or classes that are further
// away in the inheritance hierarchy.

//_________________________________________________________

def playWithOverridingAbstractMethodsInTraits = 
	// Overriding abstract methods in traits
	trait Logger :
		def log(msg: String) : Unit // This method is abstract
	/* 		 
	// This trait does not compile
	trait TimestampLogger extends Logger : 
		override def log(msg: String) = // Overrides an abstract method
			super.log(s"${java.time.Instant.now()} $msg") // Is super.log defined?
	*/

	// Declare log as abstract:
	trait TimestampLogger extends Logger : 
		abstract override def log(msg: String) =
			super.log(s"${java.time.Instant.now()} $msg")

	// Still need to mix in a concrete logger

	trait ConsoleLogger extends Logger :
		override def log(msg: String) = println(msg) 

	class Account :
		protected var balance = 0.0

	abstract class LoggedAccount extends Account, Logger :
		def withdraw(amount: Double) =
			if (amount > balance) log("Insufficient funds")
			else balance -= amount  
		// More methods ...

	def demonstration = 
		val acct = new LoggedAccount() with ConsoleLogger 
		acct.withdraw(100)

	demonstration

//_________________________________________________________


def playWithConcreteFieldsInTraits = 
	// Concrete fields in traits
	trait Logger :
		def log(msg: String): Unit

	trait ConsoleLogger extends Logger :
		def log(msg: String) = println(msg)

	trait ShortLogger extends Logger :
		val maxLength = 15 // A concrete field
		abstract override def log(msg: String) =
			super.log(
				if msg.length <= maxLength then msg
				else s"${msg.substring(0, maxLength - 1)}…")

	class Account :
		protected var balance = 0.0
		
	class SavingsAccount extends Account, ConsoleLogger, ShortLogger :
		var interest = 0.0
			def withdraw(amount: Double) =
			if (amount > balance) log("Insufficient funds")
			else balance -= amount  
		// More methods ...

	def printDeclaredFields(cl: Class[?]) =
		println(s"${cl.getName} declared fields")  
		println(cl.getDeclaredFields.map(_.toString).mkString("\n"))

	def demonstration = 
		printDeclaredFields(classOf[Account])
		printDeclaredFields(classOf[SavingsAccount])

	demonstration


def playWithAbstractFieldsInTraits = 

	// Abstract fields in traits

	trait Logger :
		def log(msg: String): Unit

	trait ConsoleLogger extends Logger :
		def log(msg: String) = println(msg)

	class Account :
		protected var balance = 0.0

	abstract class LoggedAccount extends Account, Logger :
		def withdraw(amount: Double) =
			if amount > balance then log("Insufficient funds")
			else balance -= amount  
		// More methods ...

	trait ShortLogger extends Logger :
		val maxLength: Int // An abstract field
		abstract override def log(msg: String) = 
			super.log(
				if msg.length <= maxLength then msg
				else s"${msg.substring(0, maxLength - 1)}…")
					// The maxLength field is used in the implementation

	class ShortLoggedAccount extends LoggedAccount, ConsoleLogger, ShortLogger :
		val maxLength = 20 // No override necessary

	def demonstration = 
		val acct1 = ShortLoggedAccount()
		acct1.withdraw(500)
		val acct = new LoggedAccount() with ConsoleLogger with ShortLogger :
			val maxLength = 15
		acct.withdraw(500)

	demonstration

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________


@main
def scalaTraits(): Unit = {
	println("\nFunction: playWithTraitsAsInterface")
	playWithTraitsAsInterface

	println("\nFunction: playtWithTraitsWithConcreteMethods")
	playtWithTraitsWithConcreteMethods
	
	println("\nFunction: playWithTraitsForRichInterfaces")
	playWithTraitsForRichInterfaces

	println("\nFunction: playWithObjectsWithTraits")
	playWithObjectsWithTraits

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}
