//_________________________________________________________________
//_________________________________________________________________

// package r11_pattern_matching_in_match

import System.out.{println => p}

case class Person(firstName: String, lastName: String)
case class Dog(name: String)

def playWithConstantPatterns(x: Matchable): String = x match
	// constant patterns
	case 0 			=> "zero"
	case true 		=> "true"
	case "hello" 	=> "you said 'hello'"
	case Nil 		=> "an empty List"


def playWithSequencePatterns(x: Matchable): String = x match
	// sequence patterns
	case List(0, _, _) 	=> "a 3-element list with 0 as the first element"
	case List(1, _*) 	=> "list, starts with 1, has any number of elements"


def playWithTuplePatterns(x: Matchable): String = x match
	// tuples
	case (a, b) 	=> s"got $a and $b"
	case (a, b, c) 	=> s"got $a, $b, and $c"


def playWithConstructorPatterns(x: Matchable): String = x match
	// constructor patterns
	case Person(first, "Alexander") => s"Alexander, first name = $first"
	case Dog("Suka") 				=> "found a dog named Suka"

def playWithTypePatterns(x: Matchable): String = x match
	// typed patterns
	case s: String 			=> s"got a string: $s"
	case i: Int 			=> s"got an int: $i"
	case f: Float 			=> s"got a float: $f"
	case a: Array[Int] 		=> s"array of int: ${a.mkString(",")}"
	case as: Array[String] 	=> s"string array: ${as.mkString(",")}"
	case d: Dog 			=> s"dog: ${d.name}"
	case list: List[_] 		=> s"got a List: $list"
	case m: Map[_, _] 		=> m.toString
	// the default wildcard pattern
	case _ 					=> "Unknown Value"


def playWithPatternMatchings = 
	// trigger the constant patterns
	println( playWithConstantPatterns(0))               // zero
	println( playWithConstantPatterns(true))            // true
	println( playWithConstantPatterns("hello"))         // you said 'hello'
	println( playWithConstantPatterns(Nil))             // an empty List

	// trigger the sequence patterns
	println( playWithSequencePatterns(List(0,1,2)))     // a 3-element list with 0 as the first element
	println( playWithSequencePatterns(List(1,2)))       // list, starts with 1, has any number of elements
	println( playWithSequencePatterns(List(1,2,3)))     // list, starts with 1, has any number of elements
	
	// Exception in thread "main" scala.MatchError: 
	//		Vector(1, 2, 3) (of class scala.collection.immutable.Vector1)
	// println( playWithSequencePatterns(Vector(1,2,3)))   // vector, starts w/ 1, has any number of elements

	// trigger the tuple patterns
	println( playWithTuplePatterns((1,2)))                            // got 1 and 2
	println( playWithTuplePatterns((1,2,3)))                          // got 1, 2, and 3

	// trigger the constructor patterns
	// println( playWithConstantPatterns(Dog("Suka")))                      // found a dog named Suka
	// Exception in thread "main" scala.MatchError: 
	//		Dog(Suka) (of class Dog)
	
	// println( playWithConstantPatterns(Person("Melissa", "Alexander")))   // Alexander, first name = Melissa
	// Exception in thread "main" scala.MatchError: 
	//		Person(Melissa,Alexander) (of class Person)

	// trigger the typed patterns
	println( playWithTypePatterns("Hello, world"))       // got a string: Hello, world
	println( playWithTypePatterns(42))                               // got an int: 42
	println( playWithTypePatterns(42F))                              // got a float: 42.0
	println( playWithTypePatterns(Array(1,2,3)))                     // array of int: 1,2,3
	println( playWithTypePatterns(Array("coffee", "apple pie")))     // string array: coffee,apple pie
	println( playWithTypePatterns(Dog("Fido")))                      // dog: Fido
	println( playWithTypePatterns(List("apple", "banana")))          // got a List: List(apple, banana)
	println( playWithTypePatterns(Map(1->"Al", 2->"Alexander")))     // Map(1 -> Al, 2 -> Alexander)

	// Trigger the wildcard pattern
	println( playWithTypePatterns("33d"))                            // you gave me this string: 33d


//_________________________________________________________________
// 
// Pattern Matching
// Pattern matching is a mechanism for checking a value against a pattern. 
//		A successful match can also deconstruct a value into 
//			its constituent parts. 
//			It is a more powerful version of the  switch statement in Java
//			and it can likewise be used in place of a series of 
//				if/else statements.
// 
//_________________________________________________________________

// Syntax
// A match Expression has a value, the match keyword, and 
//		at least one case clause.

def playWithMatchExpression0 =
	import scala.util.Random

	val x: Int = Random.nextInt(10)

	x match
		case 0 => "zero"
		case 1 => "one"
		case 2 => "two"
		case _ => "other"

	// The val x above is a random integer between 0 and 9. 
	//		x becomes the left operand of the match operator and on the 
	//		right is an expression with four cases. The last case _ is a 
	//		“catch all” case for any other possible Int values. 
	//
	//	Cases are also called alternatives.		

//_________________________________________________________________

// Match Expressions have a value.

def playWithMatchExpression1 = 

	def matchTest(x: Int): String = x match
		case 1 => "one"
		case 2 => "two"
		case _ => "other"

	matchTest(3)  // returns other
	matchTest(1)  // returns one

// This match expression has a type String because all of the cases 
//		return String. Therefore, the function matchTest returns a String.


//_________________________________________________________________

// Matching on Case Classes
// 		Case classes are especially useful for pattern matching.

def playWithMatchingCaseClasses =

	sealed trait Notification
	case class Email(sender: String, title: String, body: String) extends Notification
	case class SMS(caller: String, message: String) extends Notification
	case class VoiceRecording(contactName: String, link: String) extends Notification

	// Notification is a sealed trait which has three concrete Notification Types
	//		implemented with case classes Email, SMS, and VoiceRecording. 
	//		(A sealed trait can be extended only in the same file as its 
	//		declaration.) 
	//		Now we can do pattern matching on these case classes:

	def showNotification(notification: Notification): String =
		notification match
		case Email(sender, title, _) =>
			s"You got an email from $sender with title: $title"
		case SMS(number, message) =>
			s"You got an SMS from $number! Message: $message"
		case VoiceRecording(name, link) =>
			s"You received a Voice Recording from $name! Click the link to hear it: $link"

	def playWithMatchingCaseClassesLocal = 
		val someSms = SMS("12345", "Are you there?")
		val someVoiceRecording = VoiceRecording("Tom", "voicerecording.org/id/123")

		println(showNotification(someSms))  // prints You got an SMS from 12345! Message: Are you there?
		println(showNotification(someVoiceRecording))  // prints You received a Voice Recording from Tom! Click the link to hear it: voicerecording.org/id/123

	// The function showNotification takes as a parameter 
	//		The abstract type Notification and matches on the type of Notification 
	//		(i.e. it figures out whether it’s an Email, SMS, or VoiceRecording). 
	//		In the case Email(sender, title, _) the fields sender and title are used 
	//			in the return value but the body field is ignored with _.

	playWithMatchingCaseClassesLocal


//_________________________________________________________________
//
// Matching on String
// The s-interpolator allows embedding variables in strings and 
//		is also useful for pattern matching.
//
//_________________________________________________________________

def playWithMatchingString =
	val input: String = "Alice is 25 years old"

	input match
		case s"$name is $age years old" => s"$name's age is $age"
		case _ => "No match"
	// Result: "Alice's age is 25"

	// In this example, name and age extract parts of the string 
	//		based on the pattern. This is helpful for parsing structured text.
	// We can also use extractor objects for string pattern matching.

	object Age:
		def unapply(s: String): Option[Int] = s.toIntOption

	val inputAgain: String = "Alice is 25 years old"

	val (name, age) = inputAgain match
		case s"$name is ${Age(age)} years old" => (name, age)
	// name: String = Alice
	// age: Int = 25


//_________________________________________________________________
// 
// Pattern guards
// Pattern guards are boolean expressions which are used to 
//		make cases more specific. 
//		Just add if <boolean expression> after the pattern.
// 
//_________________________________________________________________


def playWithMatchingPatternGuards = 

	sealed trait Notification
	case class Email(sender: String, title: String, body: String) extends Notification
	case class SMS(caller: String, message: String) extends Notification
	case class VoiceRecording(contactName: String, link: String) extends Notification

	def showNotification(notification: Notification): String =
		notification match
		case Email(sender, title, _) =>
			s"You got an email from $sender with title: $title"
		case SMS(number, message) =>
			s"You got an SMS from $number! Message: $message"
		case VoiceRecording(name, link) =>
			s"You received a Voice Recording from $name! Click the link to hear it: $link"

	def showImportantNotification(notification: Notification, importantPeopleInfo: Seq[String]): String =
		notification match
			case Email(sender, _, _) if importantPeopleInfo.contains(sender) =>
				"You got an email from special someone!"
			case SMS(number, _) if importantPeopleInfo.contains(number) =>
				"You got an SMS from special someone!"
			case other =>
				showNotification(other) 
				// nothing special, delegate to our original showNotification function

			// In the case Email(sender, _, _) 
			//		if importantPeopleInfo.contains(sender), the pattern is matched only 
			//		if the sender is in the list of important people.

	def playWithMatchingPatternGuardsLocal = 
		val importantPeopleInfo = Seq("867-5309", "jenny@gmail.com")

		val someSms = SMS("123-4567", "Are you there?")
		val someVoiceRecording = VoiceRecording("Tom", "voicerecording.org/id/123")
		val importantEmail = Email("jenny@gmail.com", "Drinks tonight?", "I'm free after 5!")
		val importantSms = SMS("867-5309", "I'm here! Where are you?")

		println(showImportantNotification(someSms, importantPeopleInfo)) // prints You got an SMS from 123-4567! Message: Are you there?
		println(showImportantNotification(someVoiceRecording, importantPeopleInfo)) // prints You received a Voice Recording from Tom! Click the link to hear it: voicerecording.org/id/123
		println(showImportantNotification(importantEmail, importantPeopleInfo)) // prints You got an email from special someone!

		println(showImportantNotification(importantSms, importantPeopleInfo)) // prints You got an SMS from special someone!

	playWithMatchingPatternGuardsLocal



//_________________________________________________________________
// 
// Matching on Type Only
// 		You can match on the type like so:
// 
//_________________________________________________________________


sealed trait Device
case class Phone(model: String) extends Device:
	def screenOff = "Turning screen off"

case class Computer(model: String) extends Device:
	def screenSaverOn = "Turning screen saver on..."

def goIdle(device: Device): String = device match
	case p: Phone => p.screenOff
	case c: Computer => c.screenSaverOn

//	def goIdle has a different behavior depending on the type of Device. 
//		This is useful when the case needs to call a method on the pattern. 
//		It is a convention to use the first letter of the type as the case 
//		identifier (p and c in this case).

// Binding matched patterns to variables
// You can use variable binding to get type-dependent behavior while 
//		simultaneously extracting fields from the matched pattern.

def goIdleWithModel(device: Device): String = device match
	case p @ Phone(model) => s"$model: ${p.screenOff}"
	case c @ Computer(model) => s"$model: ${c.screenSaverOn}"


def playWithMatchingTypes = 
	goIdleWithModel( Phone( "iPhone 17 Pro") )
	goIdleWithModel( Computer( "Macbook Pro") )


