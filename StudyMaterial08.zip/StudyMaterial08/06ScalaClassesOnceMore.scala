
//_________________________________________________________________
//_________________________________________________________________


def playWithExtendingClass = 
	class Person :
		var name = ""

	class Employee extends Person :
		var salary = 0.0
		def description = "An employee with name " + name + " and salary " + salary

	def demo =
		val fred = Employee()
		fred.name = "Fred"
		fred.salary = 50000
		println(fred.description)

	demo


//_________________________________________________________


def	playWithOverridingMethods =

	class Person :
		var name = ""
		override def toString = s"${getClass.getName}[name=$name]"

	class Employee extends Person :
		var salary = 0.0
		override def toString = s"${super.toString}[salary=$salary]"

	def demo =
		val fred = Employee()
		fred.name = "Fred"
		fred.salary = 50000
		println(fred)

	demo

//_________________________________________________________

def playWithTypeChecksAndCasts = 
	class Person :
		var name = ""
		override def toString = getClass.getName + "[name=" + name + "]"

	class Employee extends Person :
		var salary = 0.0
		override def toString = super.toString + "[salary=" + salary + "]"

	class Manager extends Employee

	def demo = 
		val r = scala.math.random()
	
		val p = if (r < 0.33) new Person 
			else if (r < 0.67) new Employee 
			else new Manager  
		println(p)
	
		if p.isInstanceOf[Employee] then
			val s = p.asInstanceOf[Employee] // s has type Employee
			println("It's some kind of employee.")
			s.salary = 50000
	
		if p.getClass == classOf[Employee] then 
			println("It's an Employee instance")

		p match 
			case s: Employee => println("Yup, an employee") // Process s as an Employee 
			case _ => println("Nope, something else") // p wasn't an Employee


		var some: Person = Manager()

		some.isInstanceOf[Person]
		some.isInstanceOf[Employee]
		some.isInstanceOf[Manager]

		var some1: Manager = Manager()
		var some2: Employee = some1

	demo

//_________________________________________________________

def playWithSuperclassConstruction = 

	class Person(val name: String, val age: Int) :
		override def toString = getClass.getName + "[name=" + name +
			",age=" + age + "]"

	class Employee(name: String, age: Int, var salary : Double) extends
		Person(name, age) :
		override def toString = super.toString + "[salary=" + salary + "]"

	import java.nio.charset.*
	import java.nio.file.*

	class ModernPrintWriter(p: Path, cs: Charset = StandardCharsets.UTF_8) extends
		java.io.PrintWriter(Files.newBufferedWriter(p, cs))

	def demo = 
		val e = Employee("Fred", 42, 50000)
		val p = Files.createTempFile("temp", ".txt")
		val out = ModernPrintWriter(p)
		out.println(e)
		out.close()  
		println(Files.readString(p))
		Files.delete(p)

	demo

//_________________________________________________________

	// You construct an instance of an anonymous subclass 
	//	by providing construction arguments and a block with overrides.

def playWithAnonymousSubclasses = 

	class Person(val name: String) :
		def greeting = s"Hello, my name is $name"

	def demo =
		// Here, we construct an object that belongs to an anonymous subclass of Person,
		// overriding the greeting method

		val alien = new Person("Tweel") :
			override def greeting = "Greetings, Earthling!"

		println(alien.greeting)

	demo

//_________________________________________________________

// A class declared as abstract cannot be instantiated. 
// This is usually done because one or more of its methods are not defined.

// Note that you do not use the
// abstract keyword for an abstract method. You simply omit its body. A class with at least
// one abstract method must be declared abstract.

// In a subclass, you need not use the override keyword when you define a method that
// was abstract in the superclass.

// As with methods, no override keyword is required in the subclass when you define a
// field that was abstract in the superclass.

// can always customize an abstract field by using an anonymous type:

def playWithAbstractClasses = 

	abstract class Person(val name: String) :
		def id: Int 				// No method body—this is an abstract method
		override def toString = s"${getClass.getName} with name ${name} and id ${id}"

	// /Concrete subclasses must provide concrete fields
	class Employee(name: String) extends Person(name) :
		def id = name.hashCode // override keyword not required


	def demo =
		val e = Employee("Harry")
		println(e)

	demo



//_________________________________________________________

// In addition to abstract methods, a class can also have abstract fields. 
// An abstract field is simply a field without an initial value

def playWithAbstractFields = 
	abstract class Person :
		val id: Int 
			// No initializer—this is an abstract field with an abstract getter method
		var name: String 
			// Another abstract field, with abstract getter and setter methods
		override def toString = s"${getClass.getName} with name ${name} and id ${id}"

	// Concrete subclasses must provide concrete fields,
	class Employee(val id: Int) extends Person : // Subclass has concrete id property
		var name = "" // and concrete name property

	def demo =
		val wilma = Employee(1728)
		wilma.name = "Wilma"
		println(wilma)

		// As with methods, no override keyword is required in the subclass 
		//	When you define a field that was abstract in the superclass.
		// 	Can always customize an abstract field by using an anonymous type:

		val fred = new Person() {
			val id = 1729
			var name = "Fred"
		}
		println(fred)

	demo 

//_________________________________________________________

// field in Scala consists of a private field and
// accessor/mutator methods. You can override a val (or a parameterless def) with
// another val field of the same name. The subclass has a private field and a public getter,
// and the getter overrides the superclass getter (or method)

def playWithOverridingFields = 
	class Person(val name: String) :
		override def toString = s"${getClass.getName}[name=$name]"

	class SecretAgent(codename: String) extends Person(codename) :
		override val name = "secret" // Don't want to reveal name
		// [warn] cannot override val parameter value name in class Person

		override val toString = "secret" // 

	abstract class User : 
		def id: Int // Each user has an ID that is computed in some way

	class Student(override val id: Int) extends User 
		// A student ID is simply provided in the constructor

	def demo = 
		val fred = Person("Fred")
		println(fred.name)
		val james = SecretAgent("007")
		println(james.name)
		
		val u: User = Student(1729)
		println(u.id)

	demo


// IMPORTANT NOTES
// Note the following restrictions (see also Table 8–2):
// • A def can only override another def.
// • A val can only override another val or a parameterless def.
// • A var can only override an abstract var.

// CAUTION

// In Chapter 5, I said that it’s OK to use a var because you can always change your
// mind and reimplement it as a getter/setter pair. 

// However, the programmers extending your class do not have that choice. 
//		They cannot override a var with a getter/setter pair. 
//		In other words, if you provide a var, all subclasses are stuck with it.


//_________________________________________________________

// Inheritance is a powerful feature, and it can be abused. 

// The exports feature that helps Scala programmers avoid this trap by 
// making it easy to use composition and delegation instead of inheritance.
// However, many classes are explicitly designed for inheritance. 

// In Scala, you use the open keyword to mark those classes:


def playWithOpenClass = 

	// open class Person :
	// [warn] Modifier open is redundant for this definition
	
	class Person :
		var name = ""
		override def toString = getClass.getName + "[name=" + name + "]"


//_________________________________________________________


// Starting with Scala 3.1, there will be a warning if you extend a non-open class outside
// the source file in which it is declared. To avoid the warning, the file containing the
// extending class must contain the following import statement:

// If you extend a non-open class from another file and get a compiler warning, consider
// whether inheritance is appropriate in your situation. If you decide that it is, include the
// adhocExtensions import. It will signal to others that you either made a conscious choice,
// or you just wanted to shut up the compiler.

// NOTE
//  It is a syntax error to declare a final class as open. 
//	Conversely, an abstract class is automatically open.
// 		(Section 8.6, “Abstract Classes,” on page 105) 


def playWithExtendingClasses = 
	import scala.language.adhocExtensions

	// open class Person :
	// 		[warn] Modifier open is redundant for this definition

	class Person :
		var name = ""
		override def toString = getClass.getName + "[name=" + name + "]"

	// The Employee class is not open
	// class Employee extends Person:
	// 	override def toString = getClass.getName + "[name=" + name + "]"

	class Employee extends Person :
		var salary = 0.0
		override def toString = super.toString + "[salary=" + salary + "]"
			
	class Manager extends Employee

	def demo = 
		val r = scala.math.random()
		val p = if r < 0.33 then new Person 
			else if r < 0.67 then new Employee 
			else new Manager  
		
		println(p)

	demo

//_________________________________________________________

// A related concept is that of a sealed class. 
//	A sealed class has a fixed number of direct subclasses. 
//	They must all be declared in the same file.

// // PostalRates.scala
// sealed abstract class PostalRate :
// ...
// class DomesticRate extends PostalRate :
// ...
// class InternationalRate extends PostalRate :
// ...
// Trying to extend a sealed class in another file is an error, not a warning.
// Sealed classes are intended for pattern matching. 

// If the compiler knows all subclasses of a class, it can verify that 
//	a match against subclasses is exhaustive.


def playWithSealedClasses = 

	def lookup(rates: Array[(Double, Double)])(x: Double) = 
		rates.find(x <= _(0)) match
			case Some((_, price)) => price
			case None => -1

	// PostalRates.scala
	sealed abstract class PostalRate :
		 def letter(oz: Double): Double

	class DomesticRate extends PostalRate :
		 override def letter(oz: Double) = lookup(Array((1.0, 0.58), (2.0, 0.78), (3.0, 0.98), (3.5, 1.18)))(oz)

	class InternationalRate extends PostalRate :
		 override def letter(oz: Double) = lookup(Array((1.0, 1.3), (2.0, 2.25), (3.0, 3.2), (3.5, 4.14)))(oz)


	def demoSealedClasses =
		val r = scala.math.random()
		val weight = 2.1
		val rate = if r < 0.5 then DomesticRate() else InternationalRate()
	
		val result = rate match
			case r: DomesticRate => f"Domestic letter rate ${rate.letter(weight)}%.2f"
			case r: InternationalRate => f"International letter rate ${rate.letter(weight)}%.2f"
	
		println(result)

	demoSealedClasses

// This class definition won't compile because PostalRate is sealed 
		// class IntergalacticRate extends PostalRate :
		// 			override def letter(x: Double) = Double.MaxValue

//_________________________________________________________

// As in Java or C++, you can declare a field or method as protected. 
// Such a member is accessible from any subclass.

// Unlike in Java, a protected member is not visible throughout the package to which the
// class belongs. (If you want this visibility, you can use a package modifier

def playWithProtectedFieldsAndMethods = 

	class Employee(name: String, age: Int, protected var salary: Double) :
		override def toString = s"${getClass.getName}[name=${name},age=${age},salary=${salary}]"

	class Manager(name: String, age: Int, salary: Double)
			extends Employee(name, age, salary) :
		def setSalary(newSalary: Double) = // A manager's salary can never decrease
			if (newSalary > salary) salary = newSalary 

		def outranks(other: Manager) =
			salary > other.salary
			// This does not work because age isn't protected
			// age > other.age

	def demo = 
		val manager1 = Manager("Fred", 42, 100000)
		val manager2 = Manager("Wilma", 39, 120000)

		// This does not work because the protected field is not accessible
		// in the package (unlike in Java)
		// manager1.salary = 110000
		manager1.setSalary(110000)
		manager2.setSalary(90000)

		println(manager2)
		println(manager2.outranks(manager1))

	demo

//_________________________________________________________


// When you override a val in a subclass 
//		and use the value in a superclass constructor, 
// the resulting behavior is unintuitive.

def playWithConstructionOrder = 
	class Creature :
		// val range: Int = 10
		lazy val range: Int = 10

		val env: Array[Int] = Array[Int](range)

	class Ant extends Creature :
		// override val range = 2
		lazy override val range = 2
		// [error] error overriding lazy value range in class Creature of type Int;

	def demo = 
		val a = new Ant
		println(a.range)
		println(a.env.length)

	demo

// Unfortunately, we now have a problem. The range value is used in the superclass
// constructor, and the superclass constructor runs before the subclass constructor.

// Specifically, here is what happens:
// 1. The Ant constructor calls the construction.
// 		Creature constructor before doing its own
// 2. The Creature constructor sets its range field to 10.
// 3. The Creature constructor, in order to initialize the env array, calls the range() getter.
// 4. That method is overridden to yield the 
//		(as yet uninitialized) range field of the Ant class.
// 5. The range method returns 0. 
//		(That is the initial value of all integer fields when an object is allocated.)
// 6. env is set to an array of length 0.
// 7. The Ant constructor continues, setting its range field to 2.
// 		Even though it appears as if range is either 10 or 2, 
//		env has been set to an array of length 0.



// The moral is that you should not rely on the value of a val in the body of a
// constructor.
// As a remedy, you can make range into a lazy val

// Note
// At the root of the construction order problem lies a design decision of the Java
// language—namely, to allow the invocation of subclass methods in a superclass
// constructor. 

// In C++, an object’s virtual function table pointer is set to the tableof the superclass when the superclass constructor executes. Afterwards, the
// pointer is set to the subclass table. Therefore, in C++, it is not possible to modify
// constructor behavior through overriding.The Java designers felt that this
// subtlety was unnecessary, and the Java virtual machine does not adjust the
// virtual function table during construction

// Tip
// You can have the compiler check for initialization errors such as the one in this
// section by compiling with the experimental -Ysafe-init flag.



//_________________________________________________________

// The classes that
// correspond to the primitive types in the Java virtual machine, as well as the type Unit,
// extend AnyVal. You can also define your own value classes

// All other classes are subclasses of the AnyRef class. When compiling to the Java virtual
// machine, this is a synonym for the java.lang.Object class.
// Both AnyVal and AnyRef extend the Any class, the root of the hierarchy.

// The Any class defines methods isInstanceOf, asInstanceOf, and the methods for equality
// and hash codes

// AnyVal Class
// does not add any methods. It is just a marker for value types.

// The AnyRef Class 
// Adds the monitor methods wait and notify/notifyAll from the Object class. 
// It also provides a synchronized method with a function parameter. 
// That method is the equivalent of a synchronized block in Java

//----------------------------------

// Note
// Just like in Java, I suggest you stay away from wait, notify, and synchronized
// unless you have a good reason to use them instead of higher-level concurrency
// constructs.

// At the other end of the hierarchy are the Nothing and Null types.
// is the type whose sole instance is the value null. 

// You can assign null to any reference, but not to one of the value types. 

// For example, setting an Int to null is not possible. 
// This is better than in Java, where it would be possible to set an Integer wrapper to null.

//----------------------------------

//_________________________________________________________

def playWithScalaInheritanceHierarchy = 

	class Account(var balance: Double)

	class Person(val name: String) :
		def description: String = ???

	// The Person class compiles since Nothing is a subtype of every type. 
	// You can start using the class, so long as you don’t call the description method.

	def demo = 
		val account = new Account(1000.0)
		val amount = 100.0
		account.synchronized { account.balance += amount }
		println(account.balance)

		val p = Person("Wilma")
		// println(p.description)
		// Exception in thread "main" scala.NotImplementedError: an implementation is missing

		def showAny(o: Any) = println(s"${o.getClass.getName}: $o") 
		def showUnit(o: Unit) = println(s"${o.getClass.getName}: $o") 

		showAny("Hello") // Yields "java.lang.String: Hello" 
		showUnit("Hello") // Yields "void: ()"
			// "Hello" is replaced with () (with a warning)
			// [warn] Discarded non-Unit value of type String. Add `: Unit` to discard silently.

		showAny( 3 )  		// Prints class java.lang.Integer: 3
		showAny(3, 4, 5) 	// Prints class scala.Tuple3: (3,4,5)

	demo


//_________________________________________________________

class Item(val description: String, val price: Double) :
	
	final override def equals(other: Any) = 
		other.isInstanceOf[Item] && {
			val that = other.asInstanceOf[Item]
			description == that.description && price == that.price
		}

def playWithOverridingEqualsUsingTypeChecks = 

	// [warn] the type test for Item cannot be checked at runtime because it's a local class

	// class Item(val description: String, val price: Double) :		
	// 	final override def equals(other: Any) = 
	// 		other.isInstanceOf[Item] && {
	// 			// [warn] the type test for Item cannot be checked at runtime because it's a local class
	// 			val that = other.asInstanceOf[Item]
	// 			description == that.description && price == that.price
	// 		}

	def demo =
		val item1 = Item("Toaster", 29.95)
		val item2 = Item("Toaster", 29.95)
		val item3 = Item("Espresso machine", 199.95)

		println(item1 == item2)
		println(item1 == item3)

	demo

//_________________________________________________________



def playWithOverridingEqualsUsingMatch = 

	// Using match instead of asInstanceOf
	class Item(val description: String, val price: Double) :
		final override def equals(other: Any) = other match 
			case that: Item => description == that.description && price == that.price
			case _ 			=> false

	def demo =
		val item1 = Item("Toaster", 29.95)
		val item2 = Item("Toaster", 29.95)
		val item3 = Item("Espresso machine", 199.95)

		println(item1 == item2)
		println(item1 == item3)

	demo


//_________________________________________________________

// Caution
// Be sure to define the equals method with parameter type Any. 
// The following would be wrong:
//
// 		final def equals(other: Item) = ... //Don’t!
//
// This is a different method which does not override the equals method of Any.


def playWithOverridingWrongEquals =

	// Overriding the wrong equals
	class Item(val description: String, val price: Double) :
		final def equals(other: Item) = other.isInstanceOf[Item] && { // Don't!
				val that = other.asInstanceOf[Item]
				description == that.description && price == that.price
			}

	def demo =
		val item1 = Item("Toaster", 29.95)
		val item2 = Item("Toaster", 29.95)
		val item3 = Item("Espresso machine", 199.95)

		println(item1 == item2)
		println(item1 == item3)

	demo

//_________________________________________________________

// When you define equals, remember to define hashCode as well. The hash code should be
// computed only from the fields that you use in the equality check, so that equal objects
// have the same hash code. In the Item example, combine the hash codes of the fields.
//
// 		final override def hashCode = (description, price).##
//
// The ## method is a null-safe version of the hashCode method that yields 0 for null instead
// of throwing an exception.


def playWithOverridingEqualsAndHashcode =

	class Item(val description: String, val price: Double) :
		
		final override def equals(other: Any) = 
			other.isInstanceOf[Item] && {
				val that = other.asInstanceOf[Item]
				description == that.description && price == that.price
			}
		// Observe what happens if you comment out the hashCode below
		final override def hashCode = (description, price).##
		override def toString = getClass.getName + "[description=" + 
			description + ",price=" + price + "]"

	def demo =
		val item1 = Item("Toaster", 29.95)
		val item2 = Item("Toaster", 29.95)
		val item3 = Item("Espresso machine", 199.95)

		val items = scala.collection.mutable.HashSet[Item]()
		items.add(item1)
		items.add(item2)
		items.add(item3)
		println(items)

	demo 

//_________________________________________________________


// This demo shows why you shouldn't override ==
 
def playWithOverridingEqualOperator = 

	class Item(val description: String, val price: Double) :
		final def ==(other: Item) = // Don't supply == instead of equals!
			description == other.description && price == other.price
		override def toString = getClass.getName + "[description=" + 
			description + ",price=" + price + "]"

	def demo =
		val item1 = Item("Toaster", 29.95)
		val item2 = Item("Toaster", 29.95)
		val item3 = Item("Espresso machine", 199.95)

		println(item1 == item2)
		println(item1 == item3)

		val items = scala.collection.mutable.HashSet[Item]()
		items.add(item1)
		items.add(item2)
		items.add(item3)
		println(items)

	demo


//_________________________________________________________


def playWithMultiversalEquality1 = 
	
	class Item(val description: String, val price: Double) derives CanEqual :

		final override def equals(other: Any) = 
			other.isInstanceOf[Item] && {
				val that = other.asInstanceOf[Item]
				description == that.description && price == that.price
			}

	def demo =
		val item1 = Item("Toaster", 29.95)
		val item2 = Item("Toaster", 29.95)

		var result = item1 == item2
		// Comment out the next line to see the error message
		result = Item("Blackwell toaster", 29.95) == Product("Blackwell toaster") // Compile-time error
		println(result)
	demo


def playWithMultiversalEquality2 = 

	class Person(val name: String)
	class User(val id: Int)

	def demo = 
		// Comment out the next line to see the error messages
		import scala.language.strictEquality

		val fred = Person("Fred")
		println(fred == User(1729))
		println(fred == fred)

	demo


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

@main
def scalaClassesOnceMore(): Unit = {
	println("\nFunction: playWithExtendingClass")
	playWithExtendingClass

	println("\nFunction: playWithOverridingMethods")
	playWithOverridingMethods

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}
