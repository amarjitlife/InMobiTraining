
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

def factorial( number: Int ) : Int =
	var result = 1
	for i <- 1 to number do result = result * i
	result



// def sum( a: Int, b: Int ) : Int =
def sum1( a: Int, b: Int ) = {
	a + b
}

def sumAgain( a: Int, b: Int ) =
	a + b


def playWithFunctions =
	val result = factorial( 4 )
	println(s"Result : $result")

	val result1 = sum1( 99, 10 )
	println(s"Sum : $result1")

	val result2 = sumAgain( 99, 10 )
	println(s"Sum : $result2")

//_________________________________________________________

import java.time.*
def log(sb: StringBuilder, message: String) = 
	sb.append(java.time.Instant.now())
	sb.append(": ")
	sb.append(message)
	sb.append("\n")

def playWithLog =
	val sb = StringBuilder()
	log(sb, "Hello, World!")
	println( sb.toString() )

//_________________________________________________________
// Best Practice
//		Prefer Default Arguments 
//			Over Function/Constructor Overloading

// Polymorphic Function
//		Using Mechanims : Default Arguments

// Function With Default Arguments
//		Arguments Having Default Value
def decorate(string: String, left: String = "[ ", right: String = " ]" ) =
	left + string + right

def playWithDecorate =
	println( decorate("Good Evening") )
	println( decorate("Good Evening", ">>>") )
	println( decorate("Good Evening", ">>>", "<<<") )

//_________________________________________________________

// Polymoprhic Function
//		Using Mechanim: Variable Number Arguments
//	Varidiac Function
// 		Function With Variable Number of Arguments

def summation(args: Int*) =
	var result = 0
	for arg <- args do result += arg
	result

def playWithSummation =
	var result = summation(10, 20, 30, 40, 50)
	println(s"Summation : $result")

	result = summation(10, 20, 30)
	println(s"Summation : $result")

	result = summation(10, 20)
	println(s"Summation : $result")

//_________________________________________________________

// Function Type
// (Int, Int) => Int 
def sum( a: Int, b: Int ) = a + b
def sub( a: Int, b: Int ) = a - b

// Functional Paradigm
// Higher Order Function
//		Function Which Takes And/Or Returns Functions

// Object Oriented Paradigm
// Polymorphic Function
//		Using Mechanism: Passing A Behaviour Behaviour
//						 Passing A Function To Function

// Polymporhic Function

// Function Type
//		(Int, Int, (Int, Int) => ) => Int
def calculator( a: Int, b: Int, operation: (Int, Int) => Int ) : Int =
	return operation( a, b )

// Parameterless Function
def playWithCalculator =
	val aa = 50
	val bb = 20
	var result: Int = 0

	result = calculator(aa, bb, sum)
	println(s"Result : $result")

	result = calculator(aa, bb, sub)
	println(s"Result : $result")

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

@main
def scalaFunctions(): Unit = {
	println("\nFunction: playWithFunctions")
	playWithFunctions

	println("\nFunction: playWithLog")
	playWithLog

	println("\nFunction: playWithDecorate")
	playWithDecorate

	println("\nFunction: playWithSummation")
	playWithSummation

	println("\nFunction: playWithCalculator")
	playWithCalculator

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}


