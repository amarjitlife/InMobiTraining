
//_________________________________________________________
//_________________________________________________________

/*
// 	Static Use Cases In Java/C++
//		To Bind State/Behaviour with Class/Type
//		Type Member

//	Alternative Design Choices

// 1. Singleton
//		Class Having Only One Instance

// 2. Factory Method
*/



//_________________________________________________________
//
// 1. Use Case: Singleton
//		Class Having Only One Instance
//
//_________________________________________________________

package logging:
	
// In Scala
// object Class Are Singleton Classes

	object Logger:
		def info( message: String ): Unit = println(s"INFO: $message")


def playWithSingleton =

	import logging.Logger

	class Project( name: String, daysToComplete: Int )

	class Test:
		val project1 = Project("Nation Building", 99)
		val project2 = Project("Training and Learning", 30 )

		Logger.info("Created Projects")

	Test()

// The info method is visible because of the import statement, 
//		import logging.Logger.info.

//	Imports require a “stable path” to the imported symbol, and 
//		an object is a stable path.

// Note: 
//	If an object is not top-level but is nested 
//		in another class or object, then the object is 
//		“Path-Dependent” like any other member. 

//	This means that given two kinds of beverages, 
//		class Milk and class OrangeJuice, 

// 		A class member object NutritionInfo 

//		“depends” on the enclosing instance, 
//			either milk or orange juice. 

//		milk.NutritionInfo is entirely distinct from oj.NutritionInfo.


//_________________________________________________________
//
// Companion Objects
// 		An object with the same name as a class is 
//		called a companion object. 
//
//_________________________________________________________


import scala.math.{Pi, pow}

// Companion Object For Type Circle

//		A companion class or object can access 
//			the private members of its companion. 
//		Use a companion object for methods and values 
//			which are not specific to 
//			instances of the companion class.

// Note: If a class or object has a companion, both must be 
// 		defined in the same file. 

object Circle:
	private def calculateArea( radius : Double ) = Pi * pow( radius, 2.0 )

case class Circle( radius: Double ):
	import Circle.*
	def area: Double = calculateArea( radius )


def playWithCompanionObject = 
	var circle = Circle( 5.0 )
	println( circle.area )

//_________________________________________________________
//
// 2. Use Case :: Factory Method
//
//_________________________________________________________


object Email:
	def fromString( emailString: String ) : Option[Email] =
		emailString.split('@') match
			case Array(a, b) => Some( Email( a, b) )
			case _  		 => None
			

class Email( val userName: String, val domainName: String )


def playWithFactoryMethod =
	val scalaCenterEmail = Email.fromString("scala.center@inmobi.com")

	scalaCenterEmail match
		case Some(email) 	=> println(
			s"""Registered An Email...
					Username 	: ${email.userName}
					Domain Name : ${email.domainName}

			""".stripMargin )
		case None  			=> println("Error : Email Parsing Failed...")


//_________________________________________________________

// In Java
// Human gabbar = new Human();
// Safe Code Is As Follow
// if ( gabbar != null ) gabbar.dance();
//		All Types Are Nullable By Default

// In Kotlin
// 		Non Nullable Types and Nullable Types
//		Design Towards Non Nullable Rather Than Nullability

//		Nullability You Will Bring
//			To Represent Valid Values and Non A Valid Value

// Int Type Is Non Nullable = Range Of Int
// Int? Type is Nullable Type = { Range Of Int } Union { null }

// In Scala
//		All Types Are Nullable By Default

//		Using Option Types		
//			To Represent Valid Values and Non A Valid Value
//


//_________________________________________________________________
//
//	In Scala
//
// 	Option, Some, None
//_________________________________________________________________

/* 
Option, Some, None

A note about Option, Some, and None in the code above:

Option is a data type which allows for optionality. 
		It has two cases: Some and None

The Option return type can then be used in a match/case:
	For a Some result, the match knows the returned value 
		is an instance of Email, so it can access the 
			inner username and domainName.
	
	For a None result, the match knows the returned value 
		is not an instance of Email, so it prints 
			an appropriate error message.

//_________________________________________________________

// 3. Constants static final
//		1. Prefer Enums
//		2. Seperate Constants From Class

// In Java
class Human {
	static final int singing;
	static final int dancing;
	static final int bowling;
	static final int batting;

	// Member Instances
	// Member Functions
}

// In Java
class Human {
	HumanCapability capability;
	// Member Instances
	// Member Functions
}


class HumanCapability {
	static final int singing;
	static final int dancing;
	static final int bowling;
	static final int batting;
}

// 4. static main 
		Because Class Is Building Block
		That's why static main is Workaround

// 5. Class/Type Members Initialisation
		A. Never Ever Put A State Type Level
		B. If You End Up Doing It
				Initialisation Should Be Deterministic

		class Congress {
			// Powerful God Static Member/Object
			//		Binded God Object With Type Congress
			//		Tightly Coupled State With Type

			static val gandhi = new Mahathma() // // Object = { State, Meta State }

			// Behaviour Controlled By God Object
			static def doFunctions() {

			}
		}

// 6. Utility Methods

// 7. Static Imports
// 8. To Bind Things With Class/Type
//		Behaviour
// 9. Counting Objects
//		
	class ObjectManager {
		var objectCount = 0
		//Object Creation/Destruction
		//		Counting
	}


	val manager = new ObjectManager()

// 10. Global Objects
//		Bad Idea
// 11. Communication Betwwen The Objects
// 		and so on....

	Create Communicator Classes
	With Instance Members

*/

//_________________________________________________________________
//
// EXTRACTOR OBJECT
//_________________________________________________________________

// Extractor Objects
// 		An extractor object is an object with an unapply method. 
//		Whereas the apply method is like a constructor which 
//			takes arguments and creates an object, 

//		The unapply takes an object and tries to give back the arguments. 

//		This is most often used in Pattern Matching and Partial Functions.

// BEST PRACTICE
// 		Since a value definition can use a pattern 
//				to introduce a new variable, 
//		an extractor can be used to initialize the variable, 
//			where the unapply method supplies the value.


import scala.util.Random

object CustomerID:
	def apply( name: String ) = 
		println("apply Called...")
		s"$name--${Random.nextLong()}"

	def unapply( CustomerID: String ) : Option[ String ] = 
		println("unapply Called...")
		var stringArray: Array[String] = CustomerID.split("--")
		if (stringArray.tail.nonEmpty) Some( stringArray.head ) else None

def playWithApplyUnApply =
	val gabbar = CustomerID("Gabbar Singh")

	println("Extracting....")
	val CustomerID( name ) = gabbar: @unchecked
	println( name )

	println( gabbar )

	gabbar match {
		case CustomerID( name )  => println( name )
		case _ 					 => println("CustomerID Extraction Failed...")
	}


//_________________________________________________________
// BEST PRACTICE
// The return type of an unapply should be chosen as follows:
// 		If it is just a test, return a Boolean. 
//			For instance case even().
// 		If it returns a single sub-value of type T, 
//			return an Option[T].
// 		If you want to return several sub-values T1,...,Tn, 
//			group them in an optional tuple Option[(T1,...,Tn)].
//
// 		Sometimes, the number of values to extract isn’t fixed and 
//			we would like to return an arbitrary number of values, 
//			depending on the input. 
//
//			For this use case, you can define extractors with an 
//				unapplySeq method which returns an Option[Seq[T]]. 

//		Common Examples of these patterns include 
//		Deconstructing a List using 
//			case List(x, y, z) => 
//		Decomposing a String using a regular expression Regex, such as 
//			case r(name, remainingFields @ _*) =>.
//_________________________________________________________


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

@main
def scalaClassesMore(): Unit = {
	println("\nFunction: playWithSingleton")
	playWithSingleton

	println("\nFunction: playWithCompanionObject")
	playWithCompanionObject

	println("\nFunction: playWithFactoryMethod")
	playWithFactoryMethod

	println("\nFunction: playWithApplyUnApply")
	playWithApplyUnApply

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}


