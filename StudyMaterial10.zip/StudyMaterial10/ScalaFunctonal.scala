
//_________________________________________________________________
//_________________________________________________________________
//
// Higher-Order Functions
// Topics in This Chapter L1
// 12.1 Functions as Values
// 12.2 Anonymous Functions
// 12.3 Parameters That Are Functions
// 12.4 Parameter Inference
// 12.5 Useful Higher-Order Functions
// 12.6 Closures
// 12.7 Interoperability with Lambda Expressions
// 12.8 Currying
// 12.9 Methods for Composing, Currying, and Tupling
// 12.10 Control Abstractions
// 12.11 The return Expression
//
//_________________________________________________________________
//_________________________________________________________________

// • Functions are “first-class citizens” in Scala, just like numbers.
// • You can create anonymous functions, 
//			usually to give them to other functions.
// • A function argument specifies behavior that should be executed later.
// • Many collection methods take function parameters, 
//		applying a function to the values of the collection.
// • There are syntax shortcuts that allow you to express 
//		function parameters in a way that is short and easy to read.
// • You can create functions that operate on blocks of code 
//		and look much like the built-in control statements.

//_________________________________________________________________
//_________________________________________________________________

//_________________________________________________________________
//
//	1. What Is Code?
//
//	2. What Is System?
//
//_________________________________________________________________


//_________________________________________________________________
//
// ./ch12/src/main/scala/section1.worksheet.sc
//_________________________________________________________________

// 12.1 Functions as Values

def playWithFunctionsAsValues = 
	// Functions as values

	import scala.math.*
	val num = 3.14
	val fun = ceil

	fun(num) // 4.0
	Array(3.14, 1.42, 2.0).map(fun) // Array(4.0, 2.0, 2.0)




//_________________________________________________________________
// ./ch12/src/main/scala/section2.worksheet.sc
//_________________________________________________________________

// 12.2 Anonymous Functions

// Anonymous functions

def playWithAnonymousFunctions = 
	(x: Double) => 3 * x
	val triple = (x: Double) => 3 * x
		// just like def triple(x: Double) = 3 * x
	Array(3.14, 1.42, 2.0).map((x: Double) => 3 * x)
		// Array(9.42, 4.26, 6.0)
	// Can also use braces
	Array(3.14, 1.42, 2.0).map{ (x: Double) => 3 * x }
	// More common with infix notation
	Array(3.14, 1.42, 2.0) map { (x: Double) => 3 * x }

	// No "eta expansion" when parameterless
	def heads() = scala.math.random() < 0.5
	// heads _
	// [error] missing argument list for value of type () => Boolean

	heads()



//_________________________________________________________________
// ./ch12/src/main/scala/section3.worksheet.sc
//_________________________________________________________________

// 12.3 Parameters That Are Functions


def playWithParametersThatAreFunctions = 

	// Parameters that are functions

	import scala.math.*
	
	def valueAtOneQuarter(f: (Double) => Double) = f(0.25)

	valueAtOneQuarter(ceil) // 1.0
	valueAtOneQuarter(sqrt) // 0.5 (because 0.5 × 0.5 = 0.25)
	def mulBy(factor : Double) = (x : Double) => factor * x
	
	//?? ?
	// What Is something Type?

	// ( Double ) => (Double) => Double
	val something = mulBy 

	// (Double) => Double
	val quintuple = mulBy(5)

	val some = quintuple(20) // 100


//_________________________________________________________________
// ./ch12/src/main/scala/section4.worksheet.sc
//_________________________________________________________________

// 12.4 Parameter Inference


def playWithParameterInference = 
	// Parameter inference

	// Type
	//	( (Double) => Double ) => Double
	def valueAtOneQuarter(f: (Double) => Double) = f(0.25)
	
	val some1 = valueAtOneQuarter((x: Double) => 3 * x) // 0.75
	
	valueAtOneQuarter((x) => 3 * x)
	valueAtOneQuarter(x => 3 * x)
	valueAtOneQuarter(3 * _)
	/*
	// The following does not work:
	val fun = 3 * _ // Error: Can’t infer types
	*/
	// Remedy:
	3 * (_: Double) // OK
	val fun: (Double) => Double = 3 * _ // OK because we specified the type for fun
	// Turning methods into functions:
	(_: String).length
	(_: String).substring(_:Int, _: Int)

	class Number :
		def sum(x: Int, y: Int ) = x + y



//_________________________________________________________________
// ./ch12/src/main/scala/section5.worksheet.sc
//_________________________________________________________________

// 12.5 Useful Higher-Order Functions

// Useful higher-order functions

def playWithUsefulHigherOrderFunctions = 
	(1 to 9).map(0.1 * _)
	(1 to 9).map("*" * _).foreach(println _)
	(1 to 9).filter(_ % 2 == 0) // 2, 4, 6, 8
	(1 to 9).reduceLeft(_ * _)
	"Mary had a little lamb".split(" ").sortWith(_.length < _.length)

//_________________________________________________________________
// ./ch12/src/main/scala/section6.worksheet.sc
//_________________________________________________________________

// 12.6 Closures


// Closures

def playWithClosures = 

	def mulBy(factor : Double) =  // Enclosing Context
		(x : Double) => factor * x // Enclosed Context
	
	val triple 	= mulBy(3)
	val half 	= mulBy(0.5)

	println(s"${triple(14)} ${half(14)}") // Prints 42 7


//_________________________________________________________________
// ./ch12/src/main/scala/section7.worksheet.sc
//_________________________________________________________________

// 12.7 Interoperability with Lambda Expressions

def playWithInteroperabilityWithLambdaExpressions = 
	// Interoperability with lambda expressions

	import java.awt.event.*
	import javax.swing.*

	var counter = 0

	val button = JButton("Increment")
	button.addActionListener(event => counter += 1)

	/*
	// This does not work:
	val listener = (event: ActionEvent) => println(counter)
	button.addActionListener(listener)
		// Cannot convert a nonliteral function to a Java functional interface
	*/

	// Remedy #1:
	val listener: ActionListener = event => println(counter)
	button.addActionListener(listener) // Ok

	// Remedy #2:
	val exit = (event: ActionEvent) => if counter > 9 then System.exit(0)
	button.addActionListener(exit(_))

	val frame = new JFrame
	frame.add(button)
	frame.pack()
	frame.setVisible(true)

//_________________________________________________________________
// ./ch12/src/main/scala/section8.worksheet.sc
//_________________________________________________________________

// 12.8 Currying

def playWithCurrying = 
	// Currying

	val mul = (x: Int, y: Int) => x * y
	val mulOneAtATime = (x: Int) => ((y: Int) => x * y)
	mulOneAtATime(6)(7)
	def divOneAtATime(x: Int)(y: Int) = x / y
	val a = Array("Mary", "had", "a", "little", "lamb")
	val b = Array(4, 3, 1, 6, 5)
	a.corresponds(b)(_.length == _)

//_________________________________________________________________
// ./ch12/src/main/scala/section9.worksheet.sc
//_________________________________________________________________

// 12.9 Methods for Composing, Currying, and Tupling

def playWithMethodsComposingCurryingAndTupling = 

	// Methods for composing, currying, and tupling

	// Composing

	val sqrt = scala.math.sqrt
	val fabs: Double => Double = scala.math.abs // Need the type because abs is overloaded
	val f = sqrt compose fabs // Infix notation; could also write sqrt.compose(fabs)
	f(-9) // Yields sqrt(fabs(-9)) or 3
	val g = fabs andThen sqrt // The same as sqrt compose fabs
	g(-9)

	// Currying

	val fmax : (Double, Double) => Double = scala.math.max
		// Need the type because max is overloaded
	fmax.curried // Has type Double => Double => Double
	val h = fmax.curried(0)
	h(-9)

	// Tupling

	// val k = mul.tupled // Has type ((Int, Int)) => Int 
	// [error] Not found: mul

	val xs = Array(1, 7, 2, 9)
	val ys = Array(1000, 100, 10, 1)

	// xs.zip(ys).map(mul.tupled) // Yields Array(1000, 700, 20, 9)
	// [error] Not found: mul

	xs.zip(ys).map(_ * _) // The tuple components are passed to the function

//_________________________________________________________________
// ./ch12/src/main/scala/section10
//_________________________________________________________________



//_________________________________________________________________
// ./ch12/src/main/scala/section10/Demo.scala
//_________________________________________________________________

// 12.10 Control Abstractions

package section10 :

	// Control Abstractions

	def version1() = 
		def runInThread(block: () => Unit) =
			(new Thread :
				override def run() = block()
			).start()

		runInThread { () => println("Hi"); Thread.sleep(2000); println("Oye!!!") }

	def version2() = 
		def runInThread(block: => Unit) =
			(new Thread :
				override def run() = block 
			).start()

		runInThread { 
			println("Hi"); 
			Thread.sleep(3000); 
			println("Hoye!!!") 
		}

	def until(condition: => Boolean)(block: => Unit): Unit =
		if !condition then
			block
			until(condition)(block)

def playWithControlAbstration = 
	import section10.*
	version1()
	version2()  

	var x = 10
	until (x == 0) { 
		x -= 1
		println(x) 
	}

	Thread.sleep(2000)


	
//_________________________________________________________________
// ./ch12/src/main/scala/section11.worksheet.sc
//_________________________________________________________________

// 12.11 The return Expression

package section11:

	// Nonlocal returns

	def until(condition: => Boolean)(block: => Unit): Unit =
		if !condition then
			block
			until(condition)(block)

	def indexOf(str: String, ch: Char): Int = 
		var i = 0
		until (i == str.length) { 
			if str(i) == ch then return i
			// [warn] Non local returns are no longer supported; 
			//		use `boundary` and `boundary.break` in `scala.util` instead

			i += 1
		}
		-1


def playWithTheReturnExpression = 
	import section11.*

	// indexOf("Hello", 'l')


//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________

@main
def playWithHigherOrderFunctions =
	println(s"Function: playWithFunctionsAsValues")
	playWithFunctionsAsValues

	println(s"Function: playWithAnonymousFunctions")
	playWithAnonymousFunctions
	
	println(s"Function: playWithParametersThatAreFunctions")
	playWithParametersThatAreFunctions
	
	println(s"Function: playWithParameterInference")
	playWithParameterInference

	println(s"Function: playWithUsefulHigherOrderFunctions")
	playWithUsefulHigherOrderFunctions

	println(s"Function: playWithClosures")
	playWithClosures

	println(s"Function: playWithInteroperabilityWithLambdaExpressions")
	playWithInteroperabilityWithLambdaExpressions

	println(s"Function: playWithCurrying")
	playWithCurrying
	
	println(s"Function: playWithMethodsComposingCurryingAndTupling")
	playWithMethodsComposingCurryingAndTupling
	
	println(s"Function: playWithControlAbstration")
	playWithControlAbstration

	println(s"Function: playWithTheReturnExpression")
	playWithTheReturnExpression
	
	// println(s"Function: ")
	// println(s"Function: ")
	// println(s"Function: ")

//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________

