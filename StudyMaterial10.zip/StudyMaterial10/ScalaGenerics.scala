
//_________________________________________________________________
//
//_________________________________________________________________

// Type Parameters
// 17.1 Generic Classes
// 17.2 Generic Functions
// 17.3 Bounds for Type Variables
// 17.4 Context Bounds
// 17.5 The ClassTag Context Bound
// 17.6 Multiple Bounds
// 17.7 Type Constraints L3
// 17.8 Variance
// 17.9 Co- and Contravariant Positions
// 17.10 Objects Can’t Be Generic
// 17.11 Wildcards
// 17.12 Polymorphic Functions

//_________________________________________________________________
//_________________________________________________________________

// • Classes, traits, methods, and functions can have type parameters.
// • Place the type parameters after the name, enclosed in square brackets.
// • Type bounds have the form T <: UpperBound, T >: LowerBound, T : ContextBound.
// • You can restrict a method with a type constraint 
//		such as (given ev: T <:< UpperBound).
// • Use +T (covariance) to indicate that a generic type’s subtype relationship 
//		is in the same direction as the parameter T, or 
// • Use -T (contravariance) to indicate the reverse direction.
// • Covariance is appropriate for parameters that denote outputs, 
//			such as elements in an immutable collection.
// • Contravariance is appropriate for parameters that denote inputs
//		such as function arguments.

//_________________________________________________________________
//_________________________________________________________________

//_________________________________________________________________
//
// ./ch17/src/main/scala/section1.worksheet.sc
//_________________________________________________________________

// Type Parameters
//
// 17.1 Generic Classes

def playWithGenericClasses = 
// A generic class with two type parameters

	class Pair[T, S](val first: T, val second: S)
	// The type parameters are inferred
	val p = Pair(42, "String") // It's a Pair[Int, String]
	// You can specify the type parameters explicitly
	val p2 = Pair[Any, Any](42, "String")
	// This type is shown in infix notation

	import scala.annotation.*
	@showAsInfix class x[T, U](val first: T, val second: U)
	val p3 = x(42, "String")


//_________________________________________________________________
//
// ./ch17/src/main/scala/section2.worksheet.sc
//_________________________________________________________________

// 17.2 Generic Functions

// A generic function with a type parameter

def playWithGenericFunctions = 
	def getMiddle[T](a: Array[T]) = a(a.length / 2)
	// The type parameter is inferred
	getMiddle(Array("Mary", "had", "a", "little", "lamb")) // Calls getMiddle[String]
	// You can specify the type parameter explicitly
	val f = getMiddle[String] // The function, saved in f


//_________________________________________________________________
// ./ch17/src/main/scala/section3_1.worksheet.sc
//_________________________________________________________________

// 17.3 Bounds for Type Variables

def playWithTypeBounds1 = 
	/*
	// This won't work because T might not have a compareTo method
	class Pair[T](val first: T, val second: T) :
		def smaller = if first.compareTo(second) < 0 then first else second // Error
	*/
	// Use a bound to guarantee that T is a subtype of Comparable[T]
	class Pair[T <: Comparable[T]](val first: T, val second: T) :
		def smaller = if first.compareTo(second) < 0 then first else second
		override def toString = s"($first, $second)"

	val p = Pair("Fred", "Brooks")
	p.smaller // "Brooks"
	Pair(4, 2)

	// Because URL isn't a subtype of Comparable[URL], 
	//	you cannot form pairs of URL instances
	import java.net.URL
	val url1 = URL("http://scala-lang.org")
	val url2 = URL("http://horstmann.com")
	// val p2 = Pair(url1, url2) // Error

	// The result is a Pair[Integer], not a Pair[Int]
	val p3 = Pair(4, 2)



//_________________________________________________________________
// ./ch17/src/main/scala/section3_2.worksheet.sc
//_________________________________________________________________
// 17.3 Bounds for Type Variables


def playWithTypeBounds2 =
	// The replaceFirst method without a lower bound

	class Pair[T](val first: T, val second: T) :
		def replaceFirst(newFirst: T) = Pair[T](newFirst, second)
		override def toString = s"($first, $second)"

	val p = Pair("Fred", "Brooks")
	p.replaceFirst("Wilma")



//_________________________________________________________________
// ./ch17/src/main/scala/section3_3.worksheet.sc
//_________________________________________________________________

// 17.3 Bounds for Type Variables

def playWithTypeBounds3 = 

	// The replaceFirst method with a lower bound

	class Pair[T](val first: T, val second: T) :
		override def toString = s"($first, $second)"
		def replaceFirst[R >: T](newFirst: R) = Pair[R](newFirst, second)
		// or def replaceFirst[R >: T](newFirst: R) = Pair(newFirst, second)
		// CAUTION: This method returns a Pair[Any]
		// def replaceFirst[R](newFirst: R) = Pair(newFirst, second)

	class Person(name: String) :
		override def toString = s"Person $name"
	class Student(name: String, major: String) extends Person(name) :
		override def toString = s"Student $name majoring in $major"

	val s1 = Student("Fred", "Marketing")
	val s2 = Student("Wilma", "CS")
	val p = Pair(s1, s2)
	p.replaceFirst(Person("Barney"))


//_________________________________________________________________
// ./ch17/src/main/scala/section4.worksheet.sc
//_________________________________________________________________

// 17.4 Context Bounds

def playWithContextBounds = 
	// A context bound

	class Pair[T : Ordering](val first: T, val second: T) :
		def smaller(using ord: Ordering[T]) =
			if ord.compare(first, second) < 0 then first else second

	val p = Pair("Fred", "Brooks")
	p.smaller


//_________________________________________________________________
// ./ch17/src/main/scala/section5.worksheet.sc
//_________________________________________________________________

// 17.5 The ClassTag Context Bound

def playWithClassTagContextBound = 
	// The ClassTag context bound

	import scala.reflect.*
	def makePair[T : ClassTag](first: T, second: T) = 
		Array[T](first, second)

	makePair(4, 9)


// 17.6 Multiple Bounds


//_________________________________________________________________
// ./ch17/src/main/scala/section7_1.worksheet.sc
//_________________________________________________________________

// 17.7 Type Constraints L3

def playWithTypeConstraints1 = 
	// A type constraint

	class Pair[T](val first: T, val second: T)(using ev: T <:< Comparable[T]) :
		def smaller = if first.compareTo(second) < 0 then first else second

	val p = Pair("Fred", "Brooks")
	p.smaller


//_________________________________________________________________
// ./ch17/src/main/scala/section7_2.worksheet.sc
//_________________________________________________________________

// 17.7 Type Constraints L3


def playWithTypeConstraints2 = 

	// Type constraints that cannot be expressed as type bounds

	class Pair[T](val first: T, val second: T) :
		def smaller(using ev: T <:< Comparable[T]) =
			if first.compareTo(second) < 0 then first else second

	val p = Pair("Fred", "Brooks")
	p.smaller

	// We can form a pair of non-comparable URLs as long as we don't call smaller

	import java.net.URL
	val url1 = URL("http://scala-lang.org")
	val url2 = URL("http://horstmann.com")
	val p2 = Pair(url1, url2) // Ok

	// p2.smaller // Error

	val friends = Map("Fred" -> "Barney", "Dino" -> "Wilma")
	val friendOpt = friends.get("Wilma") // An Option[String] 
	val friendOrNull = friendOpt.orNull // A String or null

	// orNull has a constraint Null <:< A, so it can't be applied to Option[Int]
	/*
	val numberOpt = if scala.math.random() < 0.5 then Some(42) else None
	val number: Int = numberOpt.orNull // Error
	*/


//_________________________________________________________________
// ./ch17/src/main/scala/section8_1.worksheet.sc
//_________________________________________________________________

// 17.8 Variance

def playWithCovariance1 = 
	class Person(name: String) :
		override def toString = s"Person $name"
	class Student(name: String, major: String) extends Person(name) :
		override def toString = s"Student $name majoring in $major"

	// This type is covariant. See what happens if you remove the +
	class Pair[+T](val first: T, val second: T)

	def makeFriends(p: Pair[Person]) = s"${p.first} and ${p.second} are now friends"

	val fred = Student("Fred", "Marketing")
	val wilma = Student("Wilma", "CS")
	val p = Pair(fred, wilma)

	makeFriends(p)


//_________________________________________________________________
// ./ch17/src/main/scala/section8_2.worksheet.sc
//_________________________________________________________________


def playWithContravariance1 = 

	// This trait is contravariant
	trait Friend[-T] :
		def befriend(someone: T): String

	def makeFriendWith(s: Student, f: Friend[Student]) = f.befriend(s)

	class Person(name: String) extends Friend[Person] :
		override def toString = s"Person $name"
		override def befriend(someone: Person) = s"$this and $someone are now friends"
	class Student(name: String, major: String) extends Person(name) :
		override def toString = s"Student $name majoring in $major"
	val susan = Student("Susan", "CS")
	val fred = Person("Fred")

	makeFriendWith(susan, fred)

	// Function1 is contravariant in its first type parameter
	// and covariant in the second

	def friendsOfStudents(students: Seq[Student], findFriend: Function1[Student, Person]) =
		// You can write the second parameter as findFriend: Student => Person 
		for s <- students yield findFriend(s)

	def findStudentFriendsOfPerson(p: Person) : Student = susan // Susan is everyone's friend

	val wilma = Student("Wilma", "CS")
	friendsOfStudents(Array(wilma, susan), findStudentFriendsOfPerson)

//_________________________________________________________________
// ./ch17/src/main/scala/section9.worksheet.sc
//_________________________________________________________________

// 17.9 Co- and Contravariant Positions

def playWithCovariantAndContravariantPositions = 

	// Arrays are not covariant
	// val students = Array[Student](length)
	// val people: Array[Person] = students // Not legal, but suppose it was

	// Arrays are not contravariant either
	// val people = Array[Person](length)
	// val students: Array[Student] = people // Not legal, but suppose it was

	// Defining a covariant mutable pair doesn't work
	// class Pair[+T](var first: T, var second: T) // Error

	// This method is safe, but it violates the variance position rule
	// class Pair[+T](val first: T, val second: T) :
	// 		def replaceFirst(newFirst: T) = Pair[T](newFirst, second) // Error

	// Remedy: Add a type parameter
	class Pair[+T](val first: T, val second: T) :
		override def toString = s"($first, $second)"
		def replaceFirst[R >: T](newFirst: R) = Pair[R](newFirst, second)

	val p = Pair("Fred", "Brooks")
	p.replaceFirst("Wilma")


//_________________________________________________________________
// ./ch17/src/main/scala/section10.worksheet.sc
//_________________________________________________________________

// 17.10 Objects Can’t Be Generic

def playWithObjectsCannotBeGeneric = 

	// A simple List type
	abstract sealed class List[+T] :
		def isEmpty: Boolean
		def head: T
		def tail: List[T]
		override def toString = if isEmpty then "" else s"$head $tail" 

	case class NonEmpty[T](head: T, tail: List[T]) extends List[T] :
		def isEmpty = false


	// [error] A case class must have at least one parameter list
	// case class Empty[T] extends List[T] :
	// 	def isEmpty = true
	// 	def head = throw UnsupportedOperationException()
	// 	def tail = throw UnsupportedOperationException()
	

	// Try changing the declaration of Empty to an object:
	// case object Empty[T] extends List[T] : // Error

	// Remedy: 
	// case object Empty extends List[Nothing] :

	// Now you can construct a list:
	// val lst = NonEmpty(42, Empty)


//_________________________________________________________________
// ./ch17/src/main/scala/section11.worksheet.sc
//_________________________________________________________________

// 17.11 Wildcards

def playWithWildcards = 
	class Person(name: String) :
		override def toString = s"Person $name"
	class Student(name: String, major: String) extends Person(name) :
		override def toString = s"Student $name majoring in $major"

	val fred = Student("Fred", "Marketing")
	val wilma = Student("Wilma", "CS")

	// This is Scala
	def makeFriends1(people: java.util.List[? <: Person]) = s"$people are now friends" 

	val lst = java.util.ArrayList[Student]()
	lst.add(fred)
	lst.add(wilma)

	makeFriends1(lst)

	class Pair[T](var first: T, var second: T)

	// OK to call with a Pair[Student]
	def makeFriends2(p: Pair[? <: Person]) = s"${p.first} and ${p.second} are now friends" 

	makeFriends2(Pair(fred, wilma))

	import java.util.Comparator
	def min[T](p: Pair[T], comp: Comparator[? >: T]) =
		if comp.compare(p.first, p.second) < 0 then p.first else p.second

	min(Pair("Fred", "Brooks"), (s, t) => s.length - t.length)

	def minAgain[T <: Comparable[? >: T]](p: Pair[T]) =
		 if p.first.compareTo(p.second) < 0 then p.first else p.second
	minAgain(Pair("Fred", "Brooks"))


//_________________________________________________________________
// ./ch17/src/main/scala/section12.worksheet.sc
//_________________________________________________________________

// 17.12 Polymorphic Functions


def playWithPolymorphicGenericFunctions = 
	// Polymorphic functions

	// Consider this function

	def firstLast[T](a: Array[T]) = (a(0), a(a.length - 1))

	// Would like to rewrite it in the form

	// val firstLast = (a: Array[T]) => 
	// This won't work--there are no generic val

	// val firstLast[T] = (a: Array[T]) => (a(0), a(a.length - 1)) // Error

	// Here is how to do it:

	val firstLastAgain = [T] => (a: Array[T]) => (a(0), a(a.length - 1))

	// Note the polymorphic function type [T] => Array[T] => (T, T)

	// Useful for lambdas with varying types

	val tuple = (1, 3.14, "Fred")
	tuple.map([T] => (x: T) => Some(x))


//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________

@main

def playWithGenerics(): Unit =
	println("\nFunction: playWithGenericClasses")
	playWithGenericClasses

	println("\nFunction: playWithGenericFunctions")
	playWithGenericFunctions
	
	println("\nFunction: playWithTypeBounds1")
	playWithTypeBounds1

	println("\nFunction: playWithTypeBounds2")
	playWithTypeBounds2

	println("\nFunction: playWithTypeBounds3")
	playWithTypeBounds3

	println("\nFunction: playWithContextBounds")
	playWithContextBounds
	
	println("\nFunction: playWithClassTagContextBound")
	playWithClassTagContextBound
	
	println("\nFunction: playWithTypeConstraints1")
	playWithTypeConstraints1
	
	println("\nFunction: playWithTypeConstraints2")
	playWithTypeConstraints2
	
	println("\nFunction: playWithCovariance1")
	playWithCovariance1
	
	println("\nFunction: playWithContravariance1")
	playWithContravariance1
	
	println("\nFunction: playWithCovariantAndContravariantPositions")
	playWithCovariantAndContravariantPositions
	
	println("\nFunction: playWithObjectsCannotBeGeneric")
	playWithObjectsCannotBeGeneric
	
	println("\nFunction: playWithWildcards")
	playWithWildcards
		
	println("\nFunction: playWithPolymorphicGenericFunctions")
	playWithPolymorphicGenericFunctions
	
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
