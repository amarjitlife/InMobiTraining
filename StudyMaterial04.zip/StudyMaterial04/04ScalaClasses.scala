
//_________________________________________________________

// Best Practice
//		State Should Note Exposed
//			Hence Must Be Private
//		Expose Only Required API's For Type/Class

// In Scala
//		All Instance Members Are Public By Default

// In Java
//		All Instance Members Are Private By Default

class Counter:
	// Member Property
	private var value = 0
	// Method

	var something: Int = 99

	def increment() =
		value += 1

	// Method : Parameterless Method
	def current = value
/*
	def currenAgain = {
		value = 0
		// return value
	}
*/

def counterDemo = 
	val myCounter = Counter()
	var counterValue = myCounter.current

	println( s"Counter :: $counterValue")
	myCounter.increment()
	myCounter.increment()

	counterValue = myCounter.current
	println( s"Counter :: $counterValue")

	println( s"Something :: ${myCounter.something}" )
	myCounter.something = 777
	println( s"Something :: ${myCounter.something}" )

//_________________________________________________________

class `नमस्ते`:
	val value = "Namaskar"

	def dance() = 
		println("Doing नमस्ते Dance...")

def playWithSomeFunnyClass =
	val naman = `नमस्ते`()
	naman.dance()

//_________________________________________________________

def playWithSimpleClasses =
	counterDemo
	playWithSomeFunnyClass

//_________________________________________________________

class Person:
	private var privateAge = 0

	// Custom Getter
	def age = privateAge
	// Custom Setter
	def age_= (newValue: Int ) = 
		// Custom Validation
		if newValue > privateAge then privateAge = newValue


def playWithPerson =
	var gabbar = Person()

	println( gabbar.age ) // gabbar.age 

	gabbar.age = 30 // gabbar.age_( 30 )
	println( gabbar.age )

	gabbar.age = 31
	println( gabbar.age )

	gabbar.age = 25
	println( gabbar.age )

//_________________________________________________________

class Message:
	val timeStamp = java.time.Instant.now
	var text = "Hello InMobians!"

def playWithMessage =
	val message = Message()
	val t = message.timeStamp   // message.timeStamp Getter Call
	val tt = message.text 		// message.text Getter Call

	println(t)

	println(message.text)
	message.text = "Good Evening!!!" // message.text_( "Good Evening!!!") Setter Call
	println( message.text )


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

@main
def scalaClasses(): Unit = {
	println("\nFunction: playWithSimpleClasses")
	playWithSimpleClasses

	println("\nFunction: playWithPerson")
	playWithPerson

	println("\nFunction: playWithMessage")
	playWithMessage

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}


