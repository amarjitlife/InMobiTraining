
//_______________________________________________________
//
// DAY 01+02
//_______________________________________________________

ASSIGNMENTS A1: Scala REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Scala Code Done In Class

ASSIGNMENTS A2: READING AND EXPLORATION ASSIGNMENTS
	Study Following Scala Chapters
		Chapter 01: The Basics (A1)
		Chapter 02: Control Structures and Functions (A1)
		Chapter 03: Arrays (A1)
		Chapter 04: Maps and Tuples (A1)
	Reference: Scala For Impatient, 3rd Edition, Cay Hortsman

ASSIGNMENTS A3: READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter 02 : Object-Oriented Programming
	Reference: Java For Impatient, Cay Hortsman

//_______________________________________________________
//
// DAY 03
//_______________________________________________________

ASSIGNMENTS A1: Scala REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Scala Code Done In Class

ASSIGNMENTS A2: READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter 04: Classes

	Reference: Scala For Impatient, 3rd Edition, Cay Hortsman


//_______________________________________________________
//
// DAY 04
//_______________________________________________________

ASSIGNMENTS A0: READING AND EXPLORATION ASSIGNMENTS
	Study Following Scala Chapters
		Chapter 01: The Basics (A1)
		Chapter 02: Control Structures and Functions (A1)
		Chapter 03: Arrays (A1)
		Chapter 04: Maps and Tuples (A1)
	Reference: Scala For Impatient, 3rd Edition, Cay Hortsman

ASSIGNMENTS A1: Scala REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice All Code + Scala Code Done In Class

ASSIGNMENTS A2: READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter : Classes
		Chapter : Interfaces And Lambdas
	Reference: Java For Impatient, 3rd Edition, Cay Hortsman

ASSIGNMENTS A3: EXPLORATION ASSIGNMENTS
	https://medium.com/@AlexanderObregon/the-purpose-and-mechanics-of-escape-analysis-in-the-jvm-f02c17860b8c
	https://ondrej-kvasnovsky.medium.com/escape-analysis-in-the-jvm-cd08e794b8df

//_______________________________________________________
//
// DAY 05
//_______________________________________________________

ASSIGNMENTS A0: READING AND EXPLORATION ASSIGNMENTS
	Study Following Scala Chapters
		Chapter 05: Classes
	Reference: Scala For Impatient, 3rd Edition, Cay Hortsman

ASSIGNMENTS A1: Scala REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice All Code + Scala Code Done In Class

ASSIGNMENTS A2: READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter : Classes
		Chapter : Interfaces And Lambdas
	Reference: Java For Impatient, 3rd Edition, Cay Hortsman

ASSIGNMENTS A3: EXPLORATION ASSIGNMENTS
	https://medium.com/@AlexanderObregon/the-purpose-and-mechanics-of-escape-analysis-in-the-jvm-f02c17860b8c
	https://ondrej-kvasnovsky.medium.com/escape-analysis-in-the-jvm-cd08e794b8df


//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________


