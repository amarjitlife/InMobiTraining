
//_________________________________________________________

enum Color:
	case Red, Green, Blue, Pink, Yellow

def getStringForColor( color: Color ) : String =
	color match {
		case Color.Red 		=> "Red Color"
		case Color.Green 	=> "Green Color"
		case Color.Blue 	=> "Blue Color"
		case Color.Pink 	=> "Pink Color"
		case Color.Yellow 	=> "Yellow Color"
		// case _				=> "Unknown Color"
	}

// [warn] match may not be exhaustive.

def getStringForColorAgain( color: Color ) : String =
	color match {
		case Color.Red 		=> "Red Color"
		case Color.Green 	=> "Green Color"
		case Color.Blue 	=> "Blue Color"
		case Color.Pink 	=> "Pink Color"
		case Color.Yellow 	=> "Yellow Color"			
		// case _				=> "Unknown Color"
	}

def playWithColors =
	println( getStringForColor( Color.Red ) )
	println( getStringForColor( Color.Green ) )
	println( getStringForColor( Color.Blue ) )

	println( getStringForColorAgain( Color.Red ) )
	println( getStringForColorAgain( Color.Green ) )
	println( getStringForColorAgain( Color.Blue ) )

//_________________________________________________________

def getColorWarmth( color: Color ) : String =
	color match {
		case Color.Red | Color.Pink			=> "Hot Color"
		case Color.Green | Color.Yellow		=> "Cold Color"
		case Color.Blue 					=> "Neutral Color"
		// case _				=> "Unknown Color"
	}

def playWithColorWarmth =
	println( getColorWarmth( Color.Red ))
	println( getColorWarmth( Color.Green ))
	println( getColorWarmth( Color.Pink ))

//_________________________________________________________

trait Expr
class Num( val value: Int ) extends Expr
class Sum( val left: Expr, val right: Expr ) extends Expr

def eval( e: Expr ) : Int = {
	if e.isInstanceOf[Num] then {
		val ee = e.asInstanceOf[Num]
		return ee.value
	}

	if e.isInstanceOf[Sum] then {
		val ee = e.asInstanceOf[Sum]
		return eval( ee.left ) + eval( ee.right )
	}
	throw IllegalArgumentException("Uknown Expression!")
}

def playWithEval = 
	// 100 + 200
	println( eval( Sum( Num(100), Num(100) ) ) )

	// (100 + 200) + 900
	println( eval( Sum( Sum( Num(100), Num(100) ), Num(900) ) ) )

//_________________________________________________________

def evalAgain( e: Expr ) : Int = {
	if e.isInstanceOf[Num] then {
		val ee = e.asInstanceOf[Num]
		ee.value
	} else if e.isInstanceOf[Sum] then {
		val ee = e.asInstanceOf[Sum]
		evalAgain( ee.left ) + evalAgain( ee.right )
	} else { 
		throw IllegalArgumentException("Uknown Expression!")
	}
}

def playWithEvalAgain = 
	// 100 + 200
	println( evalAgain( Sum( Num(100), Num(100) ) ) )

	// (100 + 200) + 900
	println( evalAgain( Sum( Sum( Num(100), Num(100) ), Num(900) ) ) )

//_________________________________________________________

// trait Expr
// class Num( val value: Int ) extends Expr
// class Sum( val left: Expr, val right: Expr ) extends Expr

def evalulate( e: Expr ) : Int = e match {
	case e: Num 	=> e.value
	case e: Sum 	=> evalulate( e.left ) + evalulate( e.right )
	// case _ 			=> throw IllegalArgumentException("Uknown Expression!")
}

def playWithEvaluate = 
	// 100 + 200
	println( evalulate( Sum( Num(100), Num(100) ) ) )

	// (100 + 200) + 900
	println( evalulate( Sum( Sum( Num(100), Num(100) ), Num(900) ) ) )

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

@main
def hello(): Unit = {
	println("Function: playWithColors")
	playWithColors

	println("Function: playWithColorWarmth")
	playWithColorWarmth

	println("Function: playWithEval")
	playWithEval

	println("Function: playWithEvalAgain")
	playWithEvalAgain

	println("Function: playWithEvaluate")
	playWithEvaluate

	// println("Function: ")
	// println("Function: ")
	// println("Function: ")
	// println("Function: ")
	// println("Function: ")
}


