
#include <limits.h>
#include <stdio.h>
//_________________________________________________________

int summation(signed int si_a, signed int si_b) {
  signed int sum = 0;
  // Type Safe Code
  //	Respecting Type Definition Like God
  if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
      ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
    	/* Handle error */
  } else {
	    sum = si_a + si_b;
  }
  /* ... */
  return sum;
}


//_________________________________________________________

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human;

void doBhangra() {
	printf("\nOyeeee Hoyeeee...");
}

void doHipHop() {
	printf("\nDoing Hip Hop...");
}

void playWithHuman() {
	Human gabbar = { 420, "Gabbar Singh", doBhangra };
	printf("\nID : %d ", gabbar.id );
	printf("\nName  : %s ", gabbar.name );
	gabbar.dance();

	Human basanti = { 100, "Basanti", doHipHop };
	printf("\nID : %d", basanti.id );
	printf("\nName : %s", basanti.name );
	basanti.dance();
}

//_________________________________________________________

// Function Type
//		(Int, Int) -> Int

int sum(int a, int b ) { return a + b; }
int sub(int a, int b ) { return a - b; }

// Function Type
//		(Int, Int, (Int, Int) -> Int ) -> Int
// Polymorphic Function
//		Using Mechanims Passing Behaviour To Behavior
int calculator(int a, int b, int (*operation)(int, int ) ) {
	return operation(a, b);
}

void playWithCalculator() {
	int a = 40, b = 10;

	int result = calculator(a, b, sum);
	printf("\nResult : %d", result );

	result = calculator(a, b, sub);
	printf("\nResult : %d", result );	
}


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________


void main() {
	printf("\n\nFunction: playWithHuman");
	playWithHuman();

	printf("\n\nFunction: playWithCalculator");
	playWithCalculator();

	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
}

