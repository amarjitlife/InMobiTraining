
#include <limits.h>
#include <stdio.h>

//_________________________________________________________

int summation(signed int si_a, signed int si_b) {
	  signed int sum = 0;
	  // Type Safe Code
	  //	Respecting Type Definition Like God
	  if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
	      ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
	  	
	  		printf("Error Happened....")

		} else {
		    sum = si_a + si_b;
	  }

	  return sum;
}


//_________________________________________________________

typedef struct option_type {
	int value;
	int status;
} Optional;

Optional summationAgain(signed int si_a, signed int si_b) {
	  Optional sum = { 0, 0 } ;
	  // Type Safe Code
	  //	Respecting Type Definition Like God
	  if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
	      ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
	  		sum.valid = 0;
	  		sum.value = 0;
	  		printf("Error Happened....")

		} else {
		    int result = si_a + si_b;
		    sum.value = result;
		    sum.valid = 1
	  }

	  return sum;
}

// Consumer

Optional result = summationAgain( 8898989, 9090909);
if ( result.valid ) result.sum
else printf( "Invalid Result");

//_________________________________________________________

// Object = { State, Meta State }

typedef struct human_type {
	// State
		int id; 				// Instance Members
		char name[100]; // Instance Members
		
	// Meta State : State About State
		void (*dance)(); // Instance Members
} Human;



void doBhangra() {
	printf("\nOyeeee Hoyeeee...");
}

void doHipHop() {
	printf("\nDoing Hip Hop...");
}

void playWithHuman() {
	Human gabbar = { 420, "Gabbar Singh", doBhangra };
	printf("\nID : %d ", gabbar.id );
	printf("\nName  : %s ", gabbar.name );
	gabbar.dance();

	Human basanti = { 100, "Basanti", doHipHop };
	printf("\nID : %d", basanti.id );
	printf("\nName : %s", basanti.name );
	basanti.dance();
}

//_________________________________________________________

// Function Type
//		(Int, Int) -> Int

int sum(int a, int b ) { return a + b; }
int sub(int a, int b ) { return a - b; }

// Function Type
//		(Int, Int, (Int, Int) -> Int ) -> Int
// Polymorphic Function
//		Using Mechanims Passing Behaviour To Behavior
int calculator(int a, int b, int (*operation)(int, int ) ) {
	return operation(a, b);
}

void playWithCalculator() {
	int a = 40, b = 10;

	int result = calculator(a, b, sum);
	printf("\nResult : %d", result );

	result = calculator(a, b, sub);
	printf("\nResult : %d", result );	
}



//_________________________________________________________
//_________________________________________________________
//_________________________________________________________


void main() {
	printf("\n\nFunction: playWithHuman");
	playWithHuman();

	printf("\n\nFunction: playWithCalculator");
	playWithCalculator();

	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
}

