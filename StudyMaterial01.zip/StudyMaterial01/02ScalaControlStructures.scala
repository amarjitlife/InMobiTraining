

//_________________________________________________________

def playWithConditionalExpressions = {
	// In Scala, "if" is an expression with a value:
	val x = -1
	if x > 0 then 1 else -1

	// You can assign the value to a variable:
	val s = if x > 0 then 1 else -1
	println( s )

	val ss = if x > 0 then 1 else "Good Evening"
	println( ss )

		// That is nicer than making an assignment in each branch: 
	var t = 0
	if x > 0 then t = 1 else t = -1

	// With branches of different types, the result has the common supertype
	if x > 0 then "positive" else -1

	// If the "else" branch is missing, it has type Unit:
	//  Discarded non-Unit value of type String. Add `: Unit` to discard silently.
	// if x > 0 then "positive" 
	if x > 0 then "positive": Unit

	val yy = if x < 0 then println("negative")

}

//_________________________________________________________

def playWithStatementTermination = {
	// Use a semicolon to separate two statements on the same line:
	var n = 10
	var r = 1
	if n > 0 then { 
		r = r * n
		n -= 1 
	}

	if n > 0 then { r = r * n ;	n -= 1  }


	// Break a long line so that the parser can see that 
	//	it is incomplete:
	var s = 0.0
	var v = 10.0
	var a = 0.2
	var t = 0.01
	s = s + v * t + // The + tells the parser that this is not the end 
		0.5 * a * t * t
}


//_________________________________________________________

def playWithBlockExpressionsAndAssignments = {
	val x0 = 2
	val x = 5
	val y0 = 3
	val y = 7

	// The value of a block is the last expression: 
	var distance = { val dx = x - x0; val dy = y - y0; scala.math.sqrt(dx * dx + dy * dy) }

	// You can use indentation instead of braces:
	distance =
		val dx = x - x0
		val dy = y - y0
		scala.math.sqrt(dx * dx + dy * dy)

	// Block indentation is common with branches and loops:
	var a = 2
	var r = 1
	var n = 10
	if n % 2 == 0 then
		a = a * a
		n = n / 2
	else
		r = r * a
		n -= 1

	// This block has a Unit value
	{ r = r * a; n -= 1 }

	var i: Any = 0
	var j = 0

	// This assignment does not set i to 1:
	i = j = 1 // Does not set i to 1

	// Use two assignments: 
	j = 1
	i = j

}

//_________________________________________________________

def playWithGenerators = {

	// Multiple Generators:
	for
		i <- 1 to 3
		j <- 1 to 3
	do
		print(f"${10 * i + j}%3d")
		// Prints 11 12 13 21 22 23 31 32 33

	// A guard:
	for
		i <- 1 to 3
		j <- 1 to 3
		if i != j
	do
		print(f"${10 * i + j}%3d")
		// Prints 12 13 21 23 31 32

	// Defining an additional variable:
	for
		i <- 1 to 3
		from = 4 - i
		j <- from to 3
	do
		print(f"${10 * i + j}%3d")
		// Prints 13 22 23 31 32 33


	// Use semicolons if you write the loop in a single line:
	for i <- 1 to 3; from = 4 - i; j <- from to 3 if i != j do println(i * 10 + j)

	// The classic syntax uses parentheses instead of "do":
	for (i <- 1 to 3; from = 4 - i; j <- from to 3 if i != j) println(i * 10 + j)

	// Braces are ok too:
	for { i <- 1 to 3; from = 4 - i; j <- from to 3 if i != j } println(i * 10 + j)

	// A collection of yielded values is the loop's value:
	val result = for i <- 1 to 10 yield i % 3
		// Yields Vector(1, 2, 0, 1, 2, 0, 1, 2, 0, 1)

	// The collection type is compatible with the generator:
	for c <- "Hello" yield (c + 1).toChar
		// Yields the string "Ifmmp"

}
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

@main
def hello(): Unit = {
	println("Function: playWithConditionalExpressions")
	playWithConditionalExpressions
	
	println("Function: playWithStatementTermination")
	playWithStatementTermination
	
	println("Function: playWithBlockExpressionsAndAssignments")
	playWithBlockExpressionsAndAssignments

	// println("Function: ")
	// println("Function: ")
	// println("Function: ")
	// println("Function: ")
	// println("Function: ")
	// println("Function: ")
	// println("Function: ")
	// println("Function: ")
}


