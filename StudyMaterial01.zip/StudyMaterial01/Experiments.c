
#include <limits.h>

//_________________________________________________________

int sum(signed int si_a, signed int si_b) {
  signed int sum = 0;
  // Type Safe Code
  //	Respecting Type Definition Like God
  if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
      ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
    	/* Handle error */
  } else {
	    sum = si_a + si_b;
  }
  /* ... */
  return sum;
}


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________


void main() {
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
}

